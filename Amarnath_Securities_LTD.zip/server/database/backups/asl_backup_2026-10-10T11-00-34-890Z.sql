-- ====================================================
-- AMARNATH SECURITIES LIMITED (BSE: 538465)
-- Database Backup Dump: 2026-10-10T11:00:34.893Z
-- ====================================================

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(36) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `entity_type` varchar(100) NOT NULL,
  `entity_id` varchar(100) DEFAULT NULL,
  `details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`details`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_audit_created_at` (`created_at`),
  KEY `idx_audit_entity` (`entity_type`,`entity_id`),
  KEY `fk_audit_user` (`user_id`),
  CONSTRAINT `fk_audit_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `user_agent`, `created_at`) VALUES
(1, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'SEED_DATABASE', 'system', 'initial_seed', '{\"seeded_at\": \"2026-10-10 13:50:07\"}', '127.0.0.1', NULL, '2026-10-10 08:20:07'),
(2, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'FAILED_LOGIN', 'user', '698c972c-475b-4210-97c3-0eb047dbbbf9', '{\"attempts\":1}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', '2026-10-10 08:22:00'),
(3, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'FAILED_LOGIN', 'user', '698c972c-475b-4210-97c3-0eb047dbbbf9', '{\"attempts\":2}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', '2026-10-10 08:22:02'),
(4, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'FAILED_LOGIN', 'user', '698c972c-475b-4210-97c3-0eb047dbbbf9', '{\"attempts\":3}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', '2026-10-10 08:22:37'),
(5, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'FAILED_LOGIN', 'user', '698c972c-475b-4210-97c3-0eb047dbbbf9', '{\"attempts\":4}', '127.0.0.1', 'node', '2026-10-10 08:25:43'),
(6, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'USER_LOGIN', 'user', '698c972c-475b-4210-97c3-0eb047dbbbf9', '{\"role\":\"super_admin\"}', '127.0.0.1', 'node', '2026-10-10 08:25:44'),
(7, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'UPDATE_ENQUIRY_STATUS', 'enquiry', 'enq-1791620744535-2c205bc1', '{\"status\":\"in_progress\"}', '127.0.0.1', 'node', '2026-10-10 08:25:44'),
(8, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'CREATE_DOCUMENT', 'document', 'test-audit-1791620744588', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\",\"category\":\"Statutory Disclosures\",\"sourceType\":\"file_url\",\"version\":\"Version 1.0\"}', '127.0.0.1', 'node', '2026-10-10 08:25:44'),
(9, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'REPLACE_DOCUMENT_FILE', 'document', 'test-audit-1791620744588', '{\"oldVersion\":\"Version 1.0\",\"newVersion\":\"2.0\",\"changeSummary\":\"Incorporated signed secretarial compliance certificate\"}', '127.0.0.1', 'node', '2026-10-10 08:25:44'),
(10, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'UNPUBLISH_DOCUMENT', 'document', 'test-audit-1791620744588', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\",\"previousStatus\":\"published\"}', '127.0.0.1', 'node', '2026-10-10 08:25:44'),
(11, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'PUBLISH_DOCUMENT', 'document', 'test-audit-1791620744588', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\",\"previousStatus\":\"draft\"}', '127.0.0.1', 'node', '2026-10-10 08:25:44'),
(12, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'DELETE_DOCUMENT', 'document', 'test-audit-1791620744588', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\"}', '127.0.0.1', 'node', '2026-10-10 08:25:44'),
(13, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'SEED_DATABASE', 'system', 'initial_seed', '{\"seeded_at\": \"2026-10-10 13:56:15\"}', '127.0.0.1', NULL, '2026-10-10 08:26:15'),
(14, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'FAILED_LOGIN', 'user', '698c972c-475b-4210-97c3-0eb047dbbbf9', '{\"attempts\":1}', '127.0.0.1', 'node', '2026-10-10 08:29:01'),
(15, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'USER_LOGIN', 'user', '698c972c-475b-4210-97c3-0eb047dbbbf9', '{\"role\":\"super_admin\"}', '127.0.0.1', 'node', '2026-10-10 08:29:02'),
(16, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'UPDATE_ENQUIRY_STATUS', 'enquiry', 'enq-1791620942730-3abd6c29', '{\"status\":\"in_progress\"}', '127.0.0.1', 'node', '2026-10-10 08:29:02'),
(17, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'CREATE_DOCUMENT', 'document', 'test-audit-1791620942767', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\",\"category\":\"Statutory Disclosures\",\"sourceType\":\"file_url\",\"version\":\"Version 1.0\"}', '127.0.0.1', 'node', '2026-10-10 08:29:02'),
(18, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'REPLACE_DOCUMENT_FILE', 'document', 'test-audit-1791620942767', '{\"oldVersion\":\"Version 1.0\",\"newVersion\":\"2.0\",\"changeSummary\":\"Incorporated signed secretarial compliance certificate\"}', '127.0.0.1', 'node', '2026-10-10 08:29:02'),
(19, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'UNPUBLISH_DOCUMENT', 'document', 'test-audit-1791620942767', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\",\"previousStatus\":\"published\"}', '127.0.0.1', 'node', '2026-10-10 08:29:02'),
(20, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'PUBLISH_DOCUMENT', 'document', 'test-audit-1791620942767', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\",\"previousStatus\":\"draft\"}', '127.0.0.1', 'node', '2026-10-10 08:29:02'),
(21, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'DELETE_DOCUMENT', 'document', 'test-audit-1791620942767', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\"}', '127.0.0.1', 'node', '2026-10-10 08:29:02'),
(22, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'USER_LOGIN', 'user', '698c972c-475b-4210-97c3-0eb047dbbbf9', '{\"role\":\"super_admin\"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-10 08:37:57'),
(23, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'FAILED_LOGIN', 'user', '698c972c-475b-4210-97c3-0eb047dbbbf9', '{\"attempts\":1}', '127.0.0.1', 'node', '2026-10-10 08:50:05'),
(24, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'USER_LOGIN', 'user', '698c972c-475b-4210-97c3-0eb047dbbbf9', '{\"role\":\"super_admin\"}', '127.0.0.1', 'node', '2026-10-10 08:50:06'),
(25, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'UPDATE_ENQUIRY_STATUS', 'enquiry', 'enq-1791622206939-7911170d', '{\"status\":\"in_progress\"}', '127.0.0.1', 'node', '2026-10-10 08:50:06'),
(26, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'CREATE_DOCUMENT', 'document', 'test-audit-1791622206981', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\",\"category\":\"Statutory Disclosures\",\"sourceType\":\"file_url\",\"version\":\"Version 1.0\"}', '127.0.0.1', 'node', '2026-10-10 08:50:07'),
(27, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'REPLACE_DOCUMENT_FILE', 'document', 'test-audit-1791622206981', '{\"oldVersion\":\"Version 1.0\",\"newVersion\":\"2.0\",\"changeSummary\":\"Incorporated signed secretarial compliance certificate\"}', '127.0.0.1', 'node', '2026-10-10 08:50:07'),
(28, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'UNPUBLISH_DOCUMENT', 'document', 'test-audit-1791622206981', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\",\"previousStatus\":\"published\"}', '127.0.0.1', 'node', '2026-10-10 08:50:07'),
(29, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'PUBLISH_DOCUMENT', 'document', 'test-audit-1791622206981', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\",\"previousStatus\":\"draft\"}', '127.0.0.1', 'node', '2026-10-10 08:50:07'),
(30, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'DELETE_DOCUMENT', 'document', 'test-audit-1791622206981', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\"}', '127.0.0.1', 'node', '2026-10-10 08:50:07'),
(31, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'FAILED_LOGIN', 'user', '698c972c-475b-4210-97c3-0eb047dbbbf9', '{\"attempts\":1}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', '2026-10-10 09:53:41'),
(32, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'USER_LOGIN', 'user', '698c972c-475b-4210-97c3-0eb047dbbbf9', '{\"role\":\"super_admin\"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', '2026-10-10 09:54:36'),
(33, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'UNPUBLISH_DOCUMENT', 'document', 'doc-ar-2025', '{\"title\":\"31st Annual Report for the Financial Year 2024-25\",\"previousStatus\":\"published\"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', '2026-10-10 09:55:00'),
(34, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'PUBLISH_DOCUMENT', 'document', 'doc-ar-2025', '{\"title\":\"31st Annual Report for the Financial Year 2024-25\",\"previousStatus\":\"draft\"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', '2026-10-10 09:55:07'),
(35, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'UPDATE_REG46_CLAUSE', 'regulation_46_clause', '46(1)', '{\"status\":\"Company/CS Confirmation Required\"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', '2026-10-10 09:56:31'),
(36, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'UPDATE_REG46_CLAUSE', 'regulation_46_clause', '46(2)(aa)', '{\"status\":\"Complied & Published\"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', '2026-10-10 09:56:40'),
(37, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'UPDATE_REG46_CLAUSE', 'regulation_46_clause', '46(1)', '{\"status\":\"Company/CS Confirmation Required\"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', '2026-10-10 09:56:46'),
(38, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'UPDATE_REG46_CLAUSE', 'regulation_46_clause', '46(1)', '{\"status\":\"Company/CS Confirmation Required\"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', '2026-10-10 09:57:02'),
(39, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'USER_LOGIN', 'user', '698c972c-475b-4210-97c3-0eb047dbbbf9', '{\"role\":\"super_admin\"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-10 10:25:51'),
(40, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'FAILED_LOGIN', 'user', '698c972c-475b-4210-97c3-0eb047dbbbf9', '{\"attempts\":1}', '127.0.0.1', 'node', '2026-10-10 10:29:23'),
(41, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'USER_LOGIN', 'user', '698c972c-475b-4210-97c3-0eb047dbbbf9', '{\"role\":\"super_admin\"}', '127.0.0.1', 'node', '2026-10-10 10:29:24'),
(42, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'UPDATE_ENQUIRY_STATUS', 'enquiry', 'enq-1791628164511-d17607b8', '{\"status\":\"in_progress\"}', '127.0.0.1', 'node', '2026-10-10 10:29:24'),
(43, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'CREATE_DOCUMENT', 'document', 'test-audit-1791628164547', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\",\"category\":\"Statutory Disclosures\",\"sourceType\":\"file_url\",\"version\":\"Version 1.0\"}', '127.0.0.1', 'node', '2026-10-10 10:29:24'),
(44, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'REPLACE_DOCUMENT_FILE', 'document', 'test-audit-1791628164547', '{\"oldVersion\":\"Version 1.0\",\"newVersion\":\"2.0\",\"changeSummary\":\"Incorporated signed secretarial compliance certificate\"}', '127.0.0.1', 'node', '2026-10-10 10:29:24'),
(45, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'UNPUBLISH_DOCUMENT', 'document', 'test-audit-1791628164547', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\",\"previousStatus\":\"published\"}', '127.0.0.1', 'node', '2026-10-10 10:29:24'),
(46, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'PUBLISH_DOCUMENT', 'document', 'test-audit-1791628164547', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\",\"previousStatus\":\"draft\"}', '127.0.0.1', 'node', '2026-10-10 10:29:24'),
(47, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'DELETE_DOCUMENT', 'document', 'test-audit-1791628164547', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\"}', '127.0.0.1', 'node', '2026-10-10 10:29:24'),
(48, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'FAILED_LOGIN', 'user', '698c972c-475b-4210-97c3-0eb047dbbbf9', '{\"attempts\":1}', '127.0.0.1', 'node', '2026-10-10 10:50:11'),
(49, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'USER_LOGIN', 'user', '698c972c-475b-4210-97c3-0eb047dbbbf9', '{\"role\":\"super_admin\"}', '127.0.0.1', 'node', '2026-10-10 10:50:13'),
(50, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'UPDATE_ENQUIRY_STATUS', 'enquiry', 'enq-1791629413179-5ba976b6', '{\"status\":\"in_progress\"}', '127.0.0.1', 'node', '2026-10-10 10:50:13'),
(51, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'CREATE_DOCUMENT', 'document', 'test-audit-1791629413239', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\",\"category\":\"Statutory Disclosures\",\"sourceType\":\"file_url\",\"version\":\"Version 1.0\"}', '127.0.0.1', 'node', '2026-10-10 10:50:13'),
(52, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'REPLACE_DOCUMENT_FILE', 'document', 'test-audit-1791629413239', '{\"oldVersion\":\"Version 1.0\",\"newVersion\":\"2.0\",\"changeSummary\":\"Incorporated signed secretarial compliance certificate\"}', '127.0.0.1', 'node', '2026-10-10 10:50:13'),
(53, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'UNPUBLISH_DOCUMENT', 'document', 'test-audit-1791629413239', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\",\"previousStatus\":\"published\"}', '127.0.0.1', 'node', '2026-10-10 10:50:13'),
(54, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'PUBLISH_DOCUMENT', 'document', 'test-audit-1791629413239', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\",\"previousStatus\":\"draft\"}', '127.0.0.1', 'node', '2026-10-10 10:50:13'),
(55, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'DELETE_DOCUMENT', 'document', 'test-audit-1791629413239', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\"}', '127.0.0.1', 'node', '2026-10-10 10:50:13'),
(56, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'FAILED_LOGIN', 'user', '698c972c-475b-4210-97c3-0eb047dbbbf9', '{\"attempts\":1}', '127.0.0.1', 'node', '2026-10-10 10:50:49'),
(57, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'USER_LOGIN', 'user', '698c972c-475b-4210-97c3-0eb047dbbbf9', '{\"role\":\"super_admin\"}', '127.0.0.1', 'node', '2026-10-10 10:50:50'),
(58, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'UPDATE_ENQUIRY_STATUS', 'enquiry', 'enq-1791629450568-4ebd2241', '{\"status\":\"in_progress\"}', '127.0.0.1', 'node', '2026-10-10 10:50:50'),
(59, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'CREATE_DOCUMENT', 'document', 'test-audit-1791629450608', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\",\"category\":\"Statutory Disclosures\",\"sourceType\":\"file_url\",\"version\":\"Version 1.0\"}', '127.0.0.1', 'node', '2026-10-10 10:50:50'),
(60, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'REPLACE_DOCUMENT_FILE', 'document', 'test-audit-1791629450608', '{\"oldVersion\":\"Version 1.0\",\"newVersion\":\"2.0\",\"changeSummary\":\"Incorporated signed secretarial compliance certificate\"}', '127.0.0.1', 'node', '2026-10-10 10:50:50'),
(61, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'UNPUBLISH_DOCUMENT', 'document', 'test-audit-1791629450608', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\",\"previousStatus\":\"published\"}', '127.0.0.1', 'node', '2026-10-10 10:50:50'),
(62, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'PUBLISH_DOCUMENT', 'document', 'test-audit-1791629450608', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\",\"previousStatus\":\"draft\"}', '127.0.0.1', 'node', '2026-10-10 10:50:50'),
(63, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'DELETE_DOCUMENT', 'document', 'test-audit-1791629450608', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\"}', '127.0.0.1', 'node', '2026-10-10 10:50:50'),
(64, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'FAILED_LOGIN', 'user', '698c972c-475b-4210-97c3-0eb047dbbbf9', '{\"attempts\":1}', '127.0.0.1', 'node', '2026-10-10 10:52:40'),
(65, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'USER_LOGIN', 'user', '698c972c-475b-4210-97c3-0eb047dbbbf9', '{\"role\":\"super_admin\"}', '127.0.0.1', 'node', '2026-10-10 10:52:43'),
(66, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'UPDATE_ENQUIRY_STATUS', 'enquiry', 'enq-1791629563270-29ac5b4f', '{\"status\":\"in_progress\"}', '127.0.0.1', 'node', '2026-10-10 10:52:43'),
(67, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'CREATE_DOCUMENT', 'document', 'test-audit-1791629563425', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\",\"category\":\"Statutory Disclosures\",\"sourceType\":\"file_url\",\"version\":\"Version 1.0\"}', '127.0.0.1', 'node', '2026-10-10 10:52:43'),
(68, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'REPLACE_DOCUMENT_FILE', 'document', 'test-audit-1791629563425', '{\"oldVersion\":\"Version 1.0\",\"newVersion\":\"2.0\",\"changeSummary\":\"Incorporated signed secretarial compliance certificate\"}', '127.0.0.1', 'node', '2026-10-10 10:52:43'),
(69, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'UNPUBLISH_DOCUMENT', 'document', 'test-audit-1791629563425', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\",\"previousStatus\":\"published\"}', '127.0.0.1', 'node', '2026-10-10 10:52:43'),
(70, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'PUBLISH_DOCUMENT', 'document', 'test-audit-1791629563425', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\",\"previousStatus\":\"draft\"}', '127.0.0.1', 'node', '2026-10-10 10:52:43'),
(71, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'DELETE_DOCUMENT', 'document', 'test-audit-1791629563425', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\"}', '127.0.0.1', 'node', '2026-10-10 10:52:44'),
(72, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'UPDATE_SYSTEM_SETTINGS', 'system_settings', 'compliance_workflow', '{\"settingKey\":\"compliance_workflow\",\"updatedFields\":[\"defaultReviewer\",\"defaultApprover\",\"reviewCycleDays\",\"nextStatutoryReviewDate\",\"staleReviewThresholdDays\"]}', '127.0.0.1', 'node', '2026-10-10 10:52:44'),
(73, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'CREATE_USER', 'user', '4bcf3b3a-fe9a-43af-a437-11838483a991', '{\"email\":\"audit-officer-1791629564371@amarnathsecuritiesltd.com\",\"name\":\"Audit Compliance Officer\",\"role\":\"compliance_officer\"}', '127.0.0.1', 'node', '2026-10-10 10:52:45'),
(74, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'DELETE_USER', 'user', '4bcf3b3a-fe9a-43af-a437-11838483a991', '{\"email\":\"audit-officer-1791629564371@amarnathsecuritiesltd.com\",\"name\":\"Audit Compliance Officer\"}', '127.0.0.1', 'node', '2026-10-10 10:52:45'),
(75, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'UPDATE_REG46_CLAUSE', 'regulation_46_clause', '1', '{\"clause\":\"46(1)\",\"title\":\"Functional Website Maintenance\",\"previousReviewStatus\":\"Verified\",\"newReviewStatus\":\"Verified\",\"evidenceLink\":null,\"reason\":\"Automated test suite verification of website maintenance\"}', '127.0.0.1', 'node', '2026-10-10 10:52:45'),
(76, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'USER_LOGIN', 'user', '698c972c-475b-4210-97c3-0eb047dbbbf9', '{\"role\":\"super_admin\"}', '127.0.0.1', 'node', '2026-10-10 10:53:12'),
(77, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'FAILED_LOGIN', 'user', '698c972c-475b-4210-97c3-0eb047dbbbf9', '{\"attempts\":1}', '127.0.0.1', 'node', '2026-10-10 10:53:14'),
(78, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'USER_LOGIN', 'user', '698c972c-475b-4210-97c3-0eb047dbbbf9', '{\"role\":\"super_admin\"}', '127.0.0.1', 'node', '2026-10-10 10:53:15'),
(79, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'UPDATE_ENQUIRY_STATUS', 'enquiry', 'enq-1791629595617-15f66446', '{\"status\":\"in_progress\"}', '127.0.0.1', 'node', '2026-10-10 10:53:15'),
(80, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'CREATE_DOCUMENT', 'document', 'test-audit-1791629595654', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\",\"category\":\"Statutory Disclosures\",\"sourceType\":\"file_url\",\"version\":\"Version 1.0\"}', '127.0.0.1', 'node', '2026-10-10 10:53:15'),
(81, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'REPLACE_DOCUMENT_FILE', 'document', 'test-audit-1791629595654', '{\"oldVersion\":\"Version 1.0\",\"newVersion\":\"2.0\",\"changeSummary\":\"Incorporated signed secretarial compliance certificate\"}', '127.0.0.1', 'node', '2026-10-10 10:53:15'),
(82, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'UNPUBLISH_DOCUMENT', 'document', 'test-audit-1791629595654', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\",\"previousStatus\":\"published\"}', '127.0.0.1', 'node', '2026-10-10 10:53:15'),
(83, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'PUBLISH_DOCUMENT', 'document', 'test-audit-1791629595654', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\",\"previousStatus\":\"draft\"}', '127.0.0.1', 'node', '2026-10-10 10:53:15'),
(84, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'DELETE_DOCUMENT', 'document', 'test-audit-1791629595654', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\"}', '127.0.0.1', 'node', '2026-10-10 10:53:15'),
(85, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'UPDATE_SYSTEM_SETTINGS', 'system_settings', 'compliance_workflow', '{\"settingKey\":\"compliance_workflow\",\"updatedFields\":[\"defaultReviewer\",\"defaultApprover\",\"reviewCycleDays\",\"nextStatutoryReviewDate\",\"staleReviewThresholdDays\"]}', '127.0.0.1', 'node', '2026-10-10 10:53:15'),
(86, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'CREATE_USER', 'user', '3b52112a-6c64-4be2-adc8-153b8a18778c', '{\"email\":\"audit-officer-1791629595881@amarnathsecuritiesltd.com\",\"name\":\"Audit Compliance Officer\",\"role\":\"compliance_officer\"}', '127.0.0.1', 'node', '2026-10-10 10:53:16'),
(87, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'DELETE_USER', 'user', '3b52112a-6c64-4be2-adc8-153b8a18778c', '{\"email\":\"audit-officer-1791629595881@amarnathsecuritiesltd.com\",\"name\":\"Audit Compliance Officer\"}', '127.0.0.1', 'node', '2026-10-10 10:53:16'),
(88, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'UPDATE_REG46_CLAUSE', 'regulation_46_clause', '1', '{\"clause\":\"46(1)\",\"title\":\"Functional Website Maintenance\",\"previousReviewStatus\":\"Verified\",\"newReviewStatus\":\"Verified\",\"evidenceLink\":null,\"reason\":\"Automated test suite verification of website maintenance\"}', '127.0.0.1', 'node', '2026-10-10 10:53:16'),
(89, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'FAILED_LOGIN', 'user', '698c972c-475b-4210-97c3-0eb047dbbbf9', '{\"attempts\":1}', '127.0.0.1', 'node', '2026-10-10 10:54:07'),
(90, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'USER_LOGIN', 'user', '698c972c-475b-4210-97c3-0eb047dbbbf9', '{\"role\":\"super_admin\"}', '127.0.0.1', 'node', '2026-10-10 10:54:08'),
(91, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'UPDATE_ENQUIRY_STATUS', 'enquiry', 'enq-1791629648511-43cc4644', '{\"status\":\"in_progress\"}', '127.0.0.1', 'node', '2026-10-10 10:54:08'),
(92, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'CREATE_DOCUMENT', 'document', 'test-audit-1791629648563', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\",\"category\":\"Statutory Disclosures\",\"sourceType\":\"file_url\",\"version\":\"Version 1.0\"}', '127.0.0.1', 'node', '2026-10-10 10:54:08'),
(93, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'REPLACE_DOCUMENT_FILE', 'document', 'test-audit-1791629648563', '{\"oldVersion\":\"Version 1.0\",\"newVersion\":\"2.0\",\"changeSummary\":\"Incorporated signed secretarial compliance certificate\"}', '127.0.0.1', 'node', '2026-10-10 10:54:08'),
(94, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'UNPUBLISH_DOCUMENT', 'document', 'test-audit-1791629648563', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\",\"previousStatus\":\"published\"}', '127.0.0.1', 'node', '2026-10-10 10:54:08'),
(95, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'PUBLISH_DOCUMENT', 'document', 'test-audit-1791629648563', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\",\"previousStatus\":\"draft\"}', '127.0.0.1', 'node', '2026-10-10 10:54:08'),
(96, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'DELETE_DOCUMENT', 'document', 'test-audit-1791629648563', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\"}', '127.0.0.1', 'node', '2026-10-10 10:54:08'),
(97, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'UPDATE_SYSTEM_SETTINGS', 'system_settings', 'compliance_workflow', '{\"settingKey\":\"compliance_workflow\",\"updatedFields\":[\"defaultReviewer\",\"defaultApprover\",\"reviewCycleDays\",\"nextStatutoryReviewDate\",\"staleReviewThresholdDays\"]}', '127.0.0.1', 'node', '2026-10-10 10:54:08'),
(98, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'CREATE_USER', 'user', 'd9a6784a-0933-4fe2-b20b-3e24eacc60e9', '{\"email\":\"audit-officer-1791629648837@amarnathsecuritiesltd.com\",\"name\":\"Audit Compliance Officer\",\"role\":\"compliance_officer\"}', '127.0.0.1', 'node', '2026-10-10 10:54:09'),
(99, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'DELETE_USER', 'user', 'd9a6784a-0933-4fe2-b20b-3e24eacc60e9', '{\"email\":\"audit-officer-1791629648837@amarnathsecuritiesltd.com\",\"name\":\"Audit Compliance Officer\"}', '127.0.0.1', 'node', '2026-10-10 10:54:09'),
(100, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'UPDATE_REG46_CLAUSE', 'regulation_46_clause', '1', '{\"clause\":\"46(1)\",\"title\":\"Functional Website Maintenance\",\"previousReviewStatus\":\"Verified\",\"newReviewStatus\":\"Verified\",\"evidenceLink\":null,\"reason\":\"Automated test suite verification of website maintenance\"}', '127.0.0.1', 'node', '2026-10-10 10:54:09'),
(101, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'FAILED_LOGIN', 'user', '698c972c-475b-4210-97c3-0eb047dbbbf9', '{\"attempts\":1}', '127.0.0.1', 'node', '2026-10-10 10:55:07'),
(102, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'USER_LOGIN', 'user', '698c972c-475b-4210-97c3-0eb047dbbbf9', '{\"role\":\"super_admin\"}', '127.0.0.1', 'node', '2026-10-10 10:55:07'),
(103, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'UPDATE_ENQUIRY_STATUS', 'enquiry', 'enq-1791629707703-cd20a52f', '{\"status\":\"in_progress\"}', '127.0.0.1', 'node', '2026-10-10 10:55:07'),
(104, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'CREATE_DOCUMENT', 'document', 'test-audit-1791629707732', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\",\"category\":\"Statutory Disclosures\",\"sourceType\":\"file_url\",\"version\":\"Version 1.0\"}', '127.0.0.1', 'node', '2026-10-10 10:55:07'),
(105, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'REPLACE_DOCUMENT_FILE', 'document', 'test-audit-1791629707732', '{\"oldVersion\":\"Version 1.0\",\"newVersion\":\"2.0\",\"changeSummary\":\"Incorporated signed secretarial compliance certificate\"}', '127.0.0.1', 'node', '2026-10-10 10:55:07'),
(106, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'UNPUBLISH_DOCUMENT', 'document', 'test-audit-1791629707732', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\",\"previousStatus\":\"published\"}', '127.0.0.1', 'node', '2026-10-10 10:55:07'),
(107, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'PUBLISH_DOCUMENT', 'document', 'test-audit-1791629707732', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\",\"previousStatus\":\"draft\"}', '127.0.0.1', 'node', '2026-10-10 10:55:07'),
(108, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'DELETE_DOCUMENT', 'document', 'test-audit-1791629707732', '{\"title\":\"Q3 FY 2025-26 Compliance Audit Test Document\"}', '127.0.0.1', 'node', '2026-10-10 10:55:07'),
(109, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'UPDATE_SYSTEM_SETTINGS', 'system_settings', 'compliance_workflow', '{\"settingKey\":\"compliance_workflow\",\"updatedFields\":[\"defaultReviewer\",\"defaultApprover\",\"reviewCycleDays\",\"nextStatutoryReviewDate\",\"staleReviewThresholdDays\"]}', '127.0.0.1', 'node', '2026-10-10 10:55:07'),
(110, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'CREATE_USER', 'user', 'ca72119c-f448-4623-937c-e500a7e1ae84', '{\"email\":\"audit-officer-1791629707871@amarnathsecuritiesltd.com\",\"name\":\"Audit Compliance Officer\",\"role\":\"compliance_officer\"}', '127.0.0.1', 'node', '2026-10-10 10:55:08'),
(111, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'DELETE_USER', 'user', 'ca72119c-f448-4623-937c-e500a7e1ae84', '{\"email\":\"audit-officer-1791629707871@amarnathsecuritiesltd.com\",\"name\":\"Audit Compliance Officer\"}', '127.0.0.1', 'node', '2026-10-10 10:55:08'),
(112, '698c972c-475b-4210-97c3-0eb047dbbbf9', 'UPDATE_REG46_CLAUSE', 'regulation_46_clause', '1', '{\"clause\":\"46(1)\",\"title\":\"Functional Website Maintenance\",\"previousReviewStatus\":\"Verified\",\"newReviewStatus\":\"Verified\",\"evidenceLink\":null,\"reason\":\"Automated test suite verification of website maintenance\"}', '127.0.0.1', 'node', '2026-10-10 10:55:08');

DROP TABLE IF EXISTS `board_committees`;
CREATE TABLE `board_committees` (
  `id` varchar(50) NOT NULL,
  `name` varchar(150) NOT NULL,
  `short_name` varchar(100) NOT NULL,
  `mandate` text NOT NULL,
  `composition_rule` text NOT NULL,
  `statutory_reference` varchar(255) NOT NULL,
  `chairperson_name` varchar(150) NOT NULL,
  `chairperson_designation` varchar(150) NOT NULL,
  `chairperson_role` varchar(50) NOT NULL DEFAULT 'Chairperson',
  `chairperson_category` varchar(50) NOT NULL,
  `meetings_frequency` varchar(255) NOT NULL,
  `key_responsibilities` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`key_responsibilities`)),
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `status` enum('draft','review','published','archived') NOT NULL DEFAULT 'published',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_committees_status` (`status`),
  KEY `idx_committees_order` (`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `board_committees` (`id`, `name`, `short_name`, `mandate`, `composition_rule`, `statutory_reference`, `chairperson_name`, `chairperson_designation`, `chairperson_role`, `chairperson_category`, `meetings_frequency`, `key_responsibilities`, `sort_order`, `status`, `created_at`, `updated_at`) VALUES
('com-audit', 'Audit Committee', 'Audit Committee', 'Oversight of financial reporting process, review of quarterly and annual financial statements, evaluation of internal financial controls, auditor independence, and approval of related party transactions.', 'Minimum 3 directors, two-thirds independent directors; Chairperson is an Independent Director with accounting or financial management expertise.', 'Section 177 of Companies Act, 2013 & Regulation 18 of SEBI (LODR) Regulations, 2015', 'Mr. Sanjay Rajkumar', 'Non-Executive Independent Director', 'Chairperson', 'Independent', 'Minimum 4 times a year with gap of not more than 120 days between consecutive meetings', '[\"Review of quarterly and annual financial statements prior to board submission\",\"Evaluation of internal financial controls and risk management systems\",\"Recommendation of appointment, remuneration, and terms of statutory and internal auditors\",\"Approval or subsequent modification of transactions with related parties under Regulation 23\",\"Review of the functioning of the whistle blower / vigil mechanism\"]', 0, 'published', '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('com-nrc', 'Nomination & Remuneration Committee', 'Nomination & Remuneration', 'Formulation of criteria for determining qualifications, positive attributes and independence of a director, evaluation of board performance, and recommendation of remuneration policy.', 'Minimum 3 non-executive directors; at least two-thirds independent directors; Chairperson is an Independent Director.', 'Section 178 of Companies Act, 2013 & Regulation 19 of SEBI (LODR) Regulations, 2015', 'Mr. Nitin Walunj', 'Non-Executive Independent Director', 'Chairperson', 'Independent', 'At least once a year', '[\"Formulation of criteria for evaluation of performance of independent directors and the board\",\"Identifying persons qualified to become directors and appointed in senior management\",\"Formulation of remuneration policy for directors, KMP and other employees\",\"Recommendation of candidates for appointment and removal across executive roles\",\"Formulation of succession planning frameworks\"]', 1, 'published', '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('com-rmc', 'Risk Management Committee', 'Risk Management', 'Monitoring and reviewing the risk management plan, cyber security frameworks, commercial viability evaluations, and statutory compliance risk mitigation.', 'Minimum 3 members with majority board members; Chairperson is a member of the Board of Directors.', 'Regulation 21 of SEBI (LODR) Regulations, 2015 & Good Corporate Governance Practices', 'Mr. Amit Priyakant Pandya', 'Whole-Time Director (Cessation filed Sep 23, 2025; Chairmanship pending CS confirmation)', 'Chairperson', 'Executive', 'At least twice a year with gap not exceeding 180 days', '[\"Periodic evaluation of operational, liquidity, market and regulatory compliance risks\",\"Formulation of business continuity and data protection guidelines\",\"Risk diagnostic review for proposed mergers, acquisitions, and strategic capital allocations\"]', 3, 'published', '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('com-src', 'Stakeholders Relationship Committee', 'Stakeholders Relationship', 'Resolving the grievances of the security holders including complaints related to transfer/transmission of shares, non-receipt of annual report, non-receipt of declared dividends, and issue of duplicate certificates.', 'Minimum 3 directors with at least one independent director; Chairperson is a Non-Executive Director.', 'Section 178(5) of Companies Act, 2013 & Regulation 20 of SEBI (LODR) Regulations, 2015', 'Ms. Vaishali Dhruvabal Mahadik', 'Non-Executive Independent Director', 'Chairperson', 'Independent', 'At least once a year', '[\"Resolving investor grievances regarding share transfer, transmission, demat and remat\",\"Review of measures taken for effective exercise of voting rights by shareholders\",\"Review of adherence to service standards adopted in respect of RTA services\",\"Monitoring grievance redressal statistics filed quarterly under Regulation 13(3)\"]', 2, 'published', '2026-10-10 08:20:07', '2026-10-10 08:20:07');

DROP TABLE IF EXISTS `committee_members`;
CREATE TABLE `committee_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `committee_id` varchar(50) NOT NULL,
  `name` varchar(150) NOT NULL,
  `designation` varchar(150) NOT NULL,
  `role` enum('Chairperson','Member') NOT NULL DEFAULT 'Member',
  `category` varchar(50) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_comm_members_comm` (`committee_id`),
  CONSTRAINT `fk_comm_members_comm` FOREIGN KEY (`committee_id`) REFERENCES `board_committees` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `committee_members` (`id`, `committee_id`, `name`, `designation`, `role`, `category`, `sort_order`) VALUES
(1, 'com-audit', 'Ms. Vaishali Dhruvabal Mahadik', 'Non-Executive Independent Director', 'Member', 'Independent', 0),
(2, 'com-audit', 'Mr. Amit Priyakant Pandya', 'Whole-Time Director (Cessation filed Sep 23, 2025; Reconstitution pending CS confirmation)', 'Member', 'Executive', 1),
(3, 'com-nrc', 'Mr. Sanjay Rajkumar', 'Non-Executive Independent Director', 'Member', 'Independent', 0),
(4, 'com-nrc', 'Ms. Vaishali Dhruvabal Mahadik', 'Non-Executive Independent Director', 'Member', 'Independent', 1),
(5, 'com-src', 'Mr. Nitin Walunj', 'Non-Executive Independent Director', 'Member', 'Independent', 0),
(6, 'com-src', 'Mr. Chetan Balubhai Patel', 'Whole-Time Director', 'Member', 'Executive', 1),
(7, 'com-rmc', 'Mr. Chetan Balubhai Patel', 'Whole-Time Director & CFO', 'Member', 'Executive', 0),
(8, 'com-rmc', 'Mr. Atul Kumar', 'Company Secretary & Compliance Officer', 'Member', 'Key Managerial Personnel (KMP)', 1);

DROP TABLE IF EXISTS `company_profile`;
CREATE TABLE `company_profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cin` varchar(30) NOT NULL,
  `bse_scrip_code` varchar(10) NOT NULL,
  `isin` varchar(20) NOT NULL,
  `company_name` varchar(200) NOT NULL,
  `short_name` varchar(100) NOT NULL,
  `tagline` varchar(255) DEFAULT NULL,
  `trust_line` varchar(255) DEFAULT NULL,
  `core_positioning` text DEFAULT NULL,
  `founded_year` varchar(10) NOT NULL,
  `email` varchar(150) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `compliance_officer` varchar(150) NOT NULL,
  `compliance_designation` varchar(150) NOT NULL,
  `compliance_email` varchar(150) NOT NULL,
  `compliance_phone` varchar(50) NOT NULL,
  `reg_office` text NOT NULL,
  `corp_office` text NOT NULL,
  `rta_name` varchar(150) NOT NULL,
  `rta_historical_liaison` varchar(150) DEFAULT NULL,
  `rta_address` text NOT NULL,
  `rta_email` varchar(150) NOT NULL,
  `rta_phone` varchar(50) NOT NULL,
  `rta_website` varchar(255) NOT NULL,
  `sebi_scores_url` varchar(255) NOT NULL,
  `sebi_smart_odr_url` varchar(255) NOT NULL,
  `bse_portal_url` varchar(255) NOT NULL,
  `status` enum('draft','published','archived') NOT NULL DEFAULT 'published',
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_by` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_company_profile_updated_by` (`updated_by`),
  CONSTRAINT `fk_company_profile_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `company_profile` (`id`, `cin`, `bse_scrip_code`, `isin`, `company_name`, `short_name`, `tagline`, `trust_line`, `core_positioning`, `founded_year`, `email`, `phone`, `compliance_officer`, `compliance_designation`, `compliance_email`, `compliance_phone`, `reg_office`, `corp_office`, `rta_name`, `rta_historical_liaison`, `rta_address`, `rta_email`, `rta_phone`, `rta_website`, `sebi_scores_url`, `sebi_smart_odr_url`, `bse_portal_url`, `status`, `updated_at`, `updated_by`) VALUES
(1, 'L67120GJ1994PLC023254', '538465', 'INE745P01010', 'Amarnath Securities Limited', 'Amarnath Securities', 'Capital. Strategy. Opportunity.', 'BSE Listed • Since 1994 • Scrip Code 538465', 'Corporate Evolution, Strategic Opportunities & Sustainable Growth', '1994', 'contact.amarnathsecurities@gmail.com', '+91 99309 82815', 'Mr. Atul Kumar', 'Company Secretary & Compliance Officer', 'contact.amarnathsecurities@gmail.com', '+91 99309 82815', '1/104, Sarthik Complex, Nr. Fun Republic, Satellite Road, Ahmedabad, Gujarat - 380015', 'Office A9, Ground Floor, Ellora Park, Near Damani Zapa, Killa Pardi, Valsad, Pardi, Gujarat, India, 396125', 'Bigshare Services Pvt. Ltd.', 'Purva Sharegistry (India) Pvt. Ltd.', 'S6-2, 6th Floor, Pinnacle Business Park, Next to Ahura Centre, Mahakali Caves Road, Andheri (East), Mumbai - 400093, Maharashtra', 'info@bigshareonline.com', '022-62638200', 'https://www.bigshareonline.com', 'https://scores.sebi.gov.in', 'https://smartodr.in', 'https://www.bseindia.com/stock-share-price/amarnath-securities-ltd/amarnath/538465/', 'published', '2026-10-10 08:20:07', '698c972c-475b-4210-97c3-0eb047dbbbf9');

DROP TABLE IF EXISTS `directors`;
CREATE TABLE `directors` (
  `id` varchar(50) NOT NULL,
  `name` varchar(150) NOT NULL,
  `designation` varchar(150) NOT NULL,
  `category` varchar(100) NOT NULL,
  `din` varchar(100) NOT NULL,
  `appointment_date` varchar(100) DEFAULT NULL,
  `term` varchar(150) DEFAULT NULL,
  `bio` text NOT NULL,
  `other_directorships` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`other_directorships`)),
  `is_verified` tinyint(1) NOT NULL DEFAULT 0,
  `approval_status` varchar(200) NOT NULL DEFAULT 'Subject to Company / CS Confirmation',
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `status` enum('draft','review','published','archived') NOT NULL DEFAULT 'published',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_directors_status` (`status`),
  KEY `idx_directors_order` (`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `directors` (`id`, `name`, `designation`, `category`, `din`, `appointment_date`, `term`, `bio`, `other_directorships`, `is_verified`, `approval_status`, `sort_order`, `status`, `created_at`, `updated_at`) VALUES
('dir-amit-pandya', 'Mr. Amit Priyakant Pandya', 'Former Whole-Time Director (Cessation Filed)', 'Executive Director', '00676479', 'Approved by BSE / MCA', 'Cessation filed on BSE (September 23, 2025)', 'Experienced corporate professional overseeing statutory operations and exchange coordination. Regulatory filings on BSE indicate cessation of directorship took effect on September 23, 2025.', '[\"Corporate entities in financial services / commerce sectors\"]', 0, 'Cessation Filed on BSE (Sep 23, 2025) - Company / CS Confirmation Required', 1, 'published', '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('dir-chetan-patel', 'Mr. Chetan Balubhai Patel', 'Whole-Time Director & CFO', 'Executive Director', '03556088', 'Approved by BSE / MCA (CFO w.e.f. July 28, 2025)', 'Key Executive Directorship & KMP (CFO)', 'Brings extensive experience in securities administration, corporate governance, balance sheet oversight and execution of corporate initiatives for listed entities. Appointed Chief Financial Officer (CFO) effective July 28, 2025.', '[\"Body Corporates registered in India (subject to annual secretarial disclosure)\"]', 1, 'Verified against MCA / BSE Records', 0, 'published', '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('dir-nitin-walunj', 'Mr. Nitin Walunj', 'Independent Director', 'Non-Executive Independent Director', 'Pending Company / CS Confirmation (Form DIR-12)', 'August 2025 (Subject to Secretarial Confirmation)', 'Appointed pursuant to Section 149 & 152 Companies Act', 'Independent professional with strategic background in commercial due diligence, corporate advisory, and stakeholder advocacy under SEBI LODR Regulations.', '[\"Professional directorships as filed in Form DIR-12\"]', 0, 'Subject to Company / CS Confirmation', 3, 'published', '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('dir-sanjay-rajkumar', 'Mr. Sanjay Rajkumar', 'Independent Director', 'Non-Executive Independent Director', 'Pending Company / CS Confirmation (Form DIR-12)', 'Appointed under Section 149 Companies Act', 'Term of 5 consecutive years (Subject to Secretarial Confirmation)', 'Chartered financial and corporate governance veteran providing independent oversight, rigorous review of financial results under Ind AS, and internal financial controls.', '[\"Independent directorships as per statutory ceiling under Regulation 17A\"]', 0, 'Subject to Company / CS Confirmation', 2, 'published', '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('dir-vaishali-mahadik', 'Ms. Vaishali Dhruvabal Mahadik', 'Independent Director', 'Non-Executive Independent Director', 'Pending Company / CS Confirmation (Form DIR-12)', 'August 2025 (Subject to Secretarial Confirmation)', 'Appointed pursuant to Section 149(1) & Regulation 17(1)(a)', 'Independent woman director bringing valuable perspectives in legal compliance, risk assessment, and shareholder grievance monitoring pursuant to SEBI Listing Regulations.', '[\"Independent positions subject to Form MBP-1 disclosures\"]', 0, 'Subject to Company / CS Confirmation', 4, 'published', '2026-10-10 08:20:07', '2026-10-10 08:20:07');

DROP TABLE IF EXISTS `document_versions`;
CREATE TABLE `document_versions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `document_id` varchar(100) NOT NULL,
  `version` varchar(30) NOT NULL,
  `file_url` varchar(500) DEFAULT NULL,
  `file_size` varchar(30) DEFAULT NULL,
  `source_type` enum('upload','file_url','external_url') NOT NULL DEFAULT 'upload',
  `change_summary` text DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_doc_vers_user` (`created_by`),
  KEY `idx_doc_vers_doc` (`document_id`),
  CONSTRAINT `fk_doc_vers_doc` FOREIGN KEY (`document_id`) REFERENCES `documents` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_doc_vers_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `documents`;
CREATE TABLE `documents` (
  `id` varchar(100) NOT NULL,
  `title` varchar(255) NOT NULL,
  `category` varchar(100) NOT NULL,
  `financial_year` varchar(30) NOT NULL,
  `quarter` varchar(30) NOT NULL DEFAULT 'N/A',
  `filing_date` varchar(50) NOT NULL,
  `bse_ack_number` varchar(100) NOT NULL,
  `file_size` varchar(30) NOT NULL,
  `file_type` enum('PDF','XBRL') NOT NULL DEFAULT 'PDF',
  `description` text NOT NULL,
  `source_type` enum('upload','file_url','external_url') NOT NULL DEFAULT 'upload',
  `file_url` varchar(500) DEFAULT NULL,
  `external_url` varchar(500) DEFAULT NULL,
  `is_available` tinyint(1) NOT NULL DEFAULT 0,
  `sebi_reference` varchar(255) DEFAULT NULL,
  `effective_date` varchar(100) DEFAULT NULL,
  `version` varchar(30) NOT NULL DEFAULT 'Version 1.0',
  `is_statutory` tinyint(1) NOT NULL DEFAULT 1,
  `status` enum('draft','review','published','archived') NOT NULL DEFAULT 'published',
  `created_by` varchar(36) DEFAULT NULL,
  `updated_by` varchar(36) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_docs_category` (`category`),
  KEY `idx_docs_year` (`financial_year`),
  KEY `idx_docs_status` (`status`),
  KEY `fk_docs_created_by` (`created_by`),
  KEY `fk_docs_updated_by` (`updated_by`),
  CONSTRAINT `fk_docs_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_docs_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `documents` (`id`, `title`, `category`, `financial_year`, `quarter`, `filing_date`, `bse_ack_number`, `file_size`, `file_type`, `description`, `source_type`, `file_url`, `external_url`, `is_available`, `sebi_reference`, `effective_date`, `version`, `is_statutory`, `status`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
('doc-agm-31-notice', 'Notice of 31st Annual General Meeting and e-Voting Information', 'AGM / EGM / Notices', 'FY 2024-25', 'Annual', '02 Sep 2025', 'BSE/LODR/20250902/551209', '1.9 MB', 'PDF', 'Notice convening the 31st AGM of members, explanatory statements under Section 102, e-voting instructions, and proxy form.', 'upload', NULL, 'https://www.bseindia.com/stock-share-price/amarnath-securities-ltd/amarnath/538465/', 0, 'Companies Act Sec 101 & Reg 44', NULL, 'Version 1.0', 1, 'published', '698c972c-475b-4210-97c3-0eb047dbbbf9', NULL, '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('doc-agm-31-voting', 'Consolidated Scrutinizer Report & Voting Results of 31st AGM', 'AGM / EGM / Notices', 'FY 2024-25', 'Annual', '26 Sep 2025', 'BSE/LODR/20250926/667102', '1.2 MB', 'PDF', 'Scrutinizer report on remote e-voting and electronic voting during the 31st AGM with resolution passage details under Regulation 44.', 'upload', NULL, 'https://www.bseindia.com/stock-share-price/amarnath-securities-ltd/amarnath/538465/', 0, 'Reg 44 SEBI (LODR)', NULL, 'Version 1.0', 1, 'published', '698c972c-475b-4210-97c3-0eb047dbbbf9', NULL, '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('doc-ar-2023', '29th Annual Report for the Financial Year 2022-23', 'Annual Reports', 'FY 2022-23', 'Annual', '28 Aug 2023', 'BSE/LODR/20230828/731902', '4.5 MB', 'PDF', 'Statutory Annual Report with Independent Audit certification.', 'upload', NULL, 'https://www.bseindia.com/stock-share-price/amarnath-securities-ltd/amarnath/538465/', 0, 'Reg 34 & Reg 46(2)(l)(iii) SEBI (LODR)', NULL, 'Version 1.0', 1, 'published', '698c972c-475b-4210-97c3-0eb047dbbbf9', NULL, '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('doc-ar-2024', '30th Annual Report for the Financial Year 2023-24', 'Annual Reports', 'FY 2023-24', 'Annual', '01 Sep 2024', 'BSE/LODR/20240901/871032', '4.8 MB', 'PDF', 'Complete 30th milestone annual corporate disclosure and governance accounts.', 'upload', NULL, 'https://www.bseindia.com/stock-share-price/amarnath-securities-ltd/amarnath/538465/', 0, 'Reg 34 & Reg 46(2)(l)(iii) SEBI (LODR)', NULL, 'Version 1.0', 1, 'published', '698c972c-475b-4210-97c3-0eb047dbbbf9', NULL, '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('doc-ar-2025', '31st Annual Report for the Financial Year 2024-25', 'Annual Reports', 'FY 2024-25', 'Annual', '31 Aug 2025', 'BSE/LODR/20250831/992104', '5.2 MB', 'PDF', 'Includes Directors Report, Management Discussion & Analysis, Corporate Governance Report, Secretarial Audit Report, and Audited Financial Accounts.', 'upload', NULL, 'https://www.bseindia.com/stock-share-price/amarnath-securities-ltd/amarnath/538465/', 0, 'Reg 34 & Reg 46(2)(l)(iii) SEBI (LODR)', NULL, 'Version 1.0', 1, 'published', '698c972c-475b-4210-97c3-0eb047dbbbf9', '698c972c-475b-4210-97c3-0eb047dbbbf9', '2026-10-10 08:20:07', '2026-10-10 09:55:07'),
('doc-bse-bm-feb26', 'Outcome of Board Meeting held on February 12, 2026', 'BSE Disclosures', 'FY 2025-26', 'Q3', '12 Feb 2026', 'BSE/LODR/20260212/894311', '950 KB', 'PDF', 'Approval of Unaudited Financial Results for Q3 FY26 and other corporate compliance matters pursuant to Regulation 30.', 'upload', '/documents/amarnath-statutory-disclosure-sample.pdf', 'https://www.bseindia.com/stock-share-price/amarnath-securities-ltd/amarnath/538465/', 1, 'Reg 30 & Reg 46(2)(w) SEBI (LODR)', NULL, 'Version 1.0', 1, 'published', '698c972c-475b-4210-97c3-0eb047dbbbf9', NULL, '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('doc-bse-closure-dec25', 'Intimation of Closure of Trading Window for Q3 FY 2025-26', 'BSE Disclosures', 'FY 2025-26', 'Q3', '30 Dec 2025', 'BSE/LODR/20251230/721094', '420 KB', 'PDF', 'Closure of trading window for designated persons pursuant to SEBI (Prohibition of Insider Trading) Regulations, 2015.', 'upload', NULL, 'https://www.bseindia.com/stock-share-price/amarnath-securities-ltd/amarnath/538465/', 0, 'SEBI (PIT) Regs & Reg 30', NULL, 'Version 1.0', 1, 'published', '698c972c-475b-4210-97c3-0eb047dbbbf9', NULL, '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('doc-bse-prior-nov25', 'Prior Intimation of Board Meeting under Regulation 29', 'BSE Disclosures', 'FY 2025-26', 'Q2', '06 Nov 2025', 'BSE/LODR/20251106/619024', '460 KB', 'PDF', 'Notice of meeting of Board of Directors to consider and approve Q2 financial statements.', 'upload', NULL, 'https://www.bseindia.com/stock-share-price/amarnath-securities-ltd/amarnath/538465/', 0, 'Reg 29 & Reg 46(2)(l)(i) SEBI (LODR)', NULL, 'Version 1.0', 1, 'published', '698c972c-475b-4210-97c3-0eb047dbbbf9', NULL, '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('doc-cg-q3-26', 'Quarterly Corporate Governance Report for Quarter ended December 31, 2025', 'Corporate Governance', 'FY 2025-26', 'Q3', '15 Jan 2026', 'BSE/LODR/20260115/104930', '650 KB', 'PDF', 'Compliance report on corporate governance pursuant to Regulation 27(2) detailing board composition and committee meetings.', 'external_url', NULL, 'https://www.bseindia.com/stock-share-price/amarnath-securities-ltd/amarnath/538465/', 1, 'Reg 27(2) SEBI (LODR)', NULL, 'Version 1.0', 1, 'published', '698c972c-475b-4210-97c3-0eb047dbbbf9', NULL, '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('doc-fr-aud-25', 'Audited Financial Results for the Quarter and Financial Year ended March 31, 2025', 'Financial Results', 'FY 2024-25', 'Q4', '28 May 2025', 'BSE/LODR/20250528/542109', '3.4 MB', 'PDF', 'Comprehensive Audited Financial Statements, Independent Auditor Report, Declaration on Unmodified Opinion and Notes.', 'upload', NULL, 'https://www.bseindia.com/stock-share-price/amarnath-securities-ltd/amarnath/538465/', 0, 'Reg 33 & Reg 46(2)(l)(ii) SEBI (LODR)', NULL, 'Version 1.0', 1, 'published', '698c972c-475b-4210-97c3-0eb047dbbbf9', NULL, '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('doc-fr-q1-26', 'Unaudited Financial Results for Quarter ended June 30, 2025', 'Financial Results', 'FY 2025-26', 'Q1', '12 Aug 2025', 'BSE/LODR/20250812/654129', '1.6 MB', 'PDF', 'First quarter financial statements and auditor review statement.', 'upload', NULL, 'https://www.bseindia.com/stock-share-price/amarnath-securities-ltd/amarnath/538465/', 0, 'Reg 33 & Reg 46(2)(l)(ii) SEBI (LODR)', NULL, 'Version 1.0', 1, 'published', '698c972c-475b-4210-97c3-0eb047dbbbf9', NULL, '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('doc-fr-q2-26', 'Unaudited Financial Results for Quarter & Half Year ended September 30, 2025', 'Financial Results', 'FY 2025-26', 'Q2', '14 Nov 2025', 'BSE/LODR/20251114/782104', '2.1 MB', 'PDF', 'Standalone Financial Results along with Statement of Assets and Liabilities, Cash Flow Statement and Limited Review Report.', 'upload', NULL, 'https://www.bseindia.com/stock-share-price/amarnath-securities-ltd/amarnath/538465/', 0, 'Reg 33 & Reg 46(2)(l)(ii) SEBI (LODR)', NULL, 'Version 1.0', 1, 'published', '698c972c-475b-4210-97c3-0eb047dbbbf9', NULL, '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('doc-fr-q3-26', 'Unaudited Financial Results for Quarter & Nine Months ended December 31, 2025', 'Financial Results', 'FY 2025-26', 'Q3', '12 Feb 2026', 'BSE/LODR/20260212/894102', '1.8 MB', 'PDF', 'Standalone Unaudited Financial Results along with Limited Review Report by Statutory Auditors under Regulation 33 of SEBI (LODR) Regulations, 2015.', 'file_url', '/documents/amarnath-statutory-disclosure-sample.pdf', 'https://www.bseindia.com/stock-share-price/amarnath-securities-ltd/amarnath/538465/', 1, 'Reg 33 & Reg 46(2)(l)(ii) SEBI (LODR)', NULL, 'Version 1.0', 1, 'published', '698c972c-475b-4210-97c3-0eb047dbbbf9', NULL, '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('doc-griev-q3-26', 'Statement of Investor Complaints for Quarter ended December 31, 2025', 'Investor Grievance', 'FY 2025-26', 'Q3', '10 Jan 2026', 'BSE/LODR/20260110/118293', '380 KB', 'PDF', 'Quarterly compliance statement under Regulation 13(3): Opening complaints: Nil, Received: 1, Resolved: 1, Pending: Nil.', 'upload', NULL, 'https://www.bseindia.com/stock-share-price/amarnath-securities-ltd/amarnath/538465/', 0, 'Reg 13(3) SEBI (LODR)', NULL, 'Version 1.0', 1, 'published', '698c972c-475b-4210-97c3-0eb047dbbbf9', NULL, '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('doc-mgt7-fy24', 'Annual Return for the Financial Year 2023-24 (Form MGT-7)', 'Annual Return (MGT-7)', 'FY 2023-24', 'Annual', '25 Oct 2024', 'ROC/GUJ/MGT7/2024/88102', '2.6 MB', 'PDF', 'Statutory Annual Return for FY 2023-24 under Section 92(3) of the Companies Act, 2013 detailing shareholding, indebtedness, and directorship changes.', 'upload', NULL, 'https://www.bseindia.com/stock-share-price/amarnath-securities-ltd/amarnath/538465/', 0, 'Sec 92 Companies Act & Reg 46(2)(z)', '31 Mar 2024', 'Version 1.0', 1, 'published', '698c972c-475b-4210-97c3-0eb047dbbbf9', NULL, '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('doc-mgt7-fy25', 'Annual Return for the Financial Year 2024-25 (Form MGT-7)', 'Annual Return (MGT-7)', 'FY 2024-25', 'Annual', '28 Oct 2025', 'ROC/GUJ/MGT7/2025/99120', '2.8 MB', 'PDF', 'Statutory Annual Return prepared pursuant to Section 92(3) of the Companies Act, 2013 and Rule 12 of the Companies (Management and Administration) Rules, 2014.', 'upload', NULL, 'https://www.bseindia.com/stock-share-price/amarnath-securities-ltd/amarnath/538465/', 0, 'Sec 92 Companies Act & Reg 46(2)(z)', '31 Mar 2025', 'Version 1.0', 1, 'published', '698c972c-475b-4210-97c3-0eb047dbbbf9', NULL, '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('doc-moa-aoa', 'Memorandum of Association & Articles of Association (MOA & AOA)', 'MOA & AOA', 'FY 2025-26', 'Annual', '15 Jan 2026', 'BSE/CORP/MOA-AOA/2026', '3.8 MB', 'PDF', 'Fundamental Constitutional Charter documents of Amarnath Securities Limited as registered with the Registrar of Companies, Gujarat.', 'upload', NULL, 'https://www.bseindia.com/stock-share-price/amarnath-securities-ltd/amarnath/538465/', 0, 'Reg 46(2)(aa) SEBI (LODR)', 'Incorporation 1994 (As amended)', 'Version 2.2', 1, 'published', '698c972c-475b-4210-97c3-0eb047dbbbf9', NULL, '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('doc-np-agm31-notice', 'Newspaper Notice of 31st Annual General Meeting, Book Closure & e-Voting', 'Newspaper Publications', 'FY 2024-25', 'Annual', '03 Sep 2025', 'BSE/NP/20250903/442019', '1.5 MB', 'PDF', 'Notice of 31st AGM, cut-off dates, remote e-voting guidelines, and book closure published in national and regional newspapers.', 'upload', NULL, 'https://www.bseindia.com/stock-share-price/amarnath-securities-ltd/amarnath/538465/', 0, 'Reg 47(1)(d) & Reg 46(2)(q) SEBI (LODR)', NULL, 'Version 1.0', 1, 'published', '698c972c-475b-4210-97c3-0eb047dbbbf9', NULL, '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('doc-np-bm-notice-q3-26', 'Newspaper Notice of Board Meeting to consider Q3 Financial Results', 'Newspaper Publications', 'FY 2025-26', 'Q3', '06 Feb 2026', 'BSE/NP/20260206/662091', '840 KB', 'PDF', 'Prior notice of meeting of the Board of Directors published in Financial Express and Western Times pursuant to Regulation 47(1)(a).', 'upload', NULL, 'https://www.bseindia.com/stock-share-price/amarnath-securities-ltd/amarnath/538465/', 0, 'Reg 47(1)(a) & Reg 46(2)(q) SEBI (LODR)', NULL, 'Version 1.0', 1, 'published', '698c972c-475b-4210-97c3-0eb047dbbbf9', NULL, '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('doc-np-q2-26', 'Newspaper Publication of Unaudited Financial Results for Q2 FY 2025-26', 'Newspaper Publications', 'FY 2025-26', 'Q2', '15 Nov 2025', 'BSE/NP/20251115/551048', '1.1 MB', 'PDF', 'Extracts of Q2 financial results published in Financial Express and Western Times.', 'upload', NULL, 'https://www.bseindia.com/stock-share-price/amarnath-securities-ltd/amarnath/538465/', 0, 'Reg 47(1)(b) & Reg 46(2)(q) SEBI (LODR)', NULL, 'Version 1.0', 1, 'published', '698c972c-475b-4210-97c3-0eb047dbbbf9', NULL, '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('doc-np-q3-26', 'Newspaper Publication of Unaudited Financial Results for Q3 FY 2025-26', 'Newspaper Publications', 'FY 2025-26', 'Q3', '13 Feb 2026', 'BSE/NP/20260213/771092', '1.2 MB', 'PDF', 'Extracts of Unaudited Standalone Financial Results published in Financial Express (English national daily) and Western Times (Gujarati regional daily) pursuant to Regulation 47(1)(b).', 'upload', NULL, 'https://www.bseindia.com/stock-share-price/amarnath-securities-ltd/amarnath/538465/', 0, 'Reg 47(1)(b) & Reg 46(2)(q) SEBI (LODR)', NULL, 'Version 1.0', 1, 'published', '698c972c-475b-4210-97c3-0eb047dbbbf9', NULL, '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('doc-pol-archival', 'Policy on Preservation of Documents & Archival Policy', 'Company Policies', 'FY 2025-26', 'Annual', '15 Apr 2025', 'BSE/CORP/POL/ARCH-07', '760 KB', 'PDF', 'Rules for document classification, retention periods (permanent vs 8 years), and website archival protocol for minimum 5 years pursuant to Regulation 9 and Regulation 30(8).', 'upload', NULL, 'https://www.bseindia.com/stock-share-price/amarnath-securities-ltd/amarnath/538465/', 0, 'Reg 9 & Reg 30(8) SEBI (LODR)', '15 Apr 2025', 'Version 1.0', 1, 'published', '698c972c-475b-4210-97c3-0eb047dbbbf9', NULL, '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('doc-pol-coc', 'Code of Conduct for Board of Directors and Senior Management Personnel', 'Company Policies', 'FY 2025-26', 'Annual', '15 Apr 2025', 'BSE/CORP/POL/COC-01', '1.0 MB', 'PDF', 'Standards of corporate integrity, conflict of interest avoidance, regulatory compliance, and fiduciary responsibility adopted pursuant to Regulation 17(5) and Regulation 46(2)(d).', 'upload', NULL, 'https://www.bseindia.com/stock-share-price/amarnath-securities-ltd/amarnath/538465/', 0, 'Reg 46(2)(d) & Reg 17(5) SEBI (LODR)', '15 Apr 2025', 'Version 3.1', 1, 'published', '698c972c-475b-4210-97c3-0eb047dbbbf9', NULL, '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('doc-pol-familiarisation', 'Details of Familiarization Programmes Imparted to Independent Directors', 'Corporate Governance', 'FY 2024-25', 'Annual', '30 Aug 2025', 'BSE/CORP/CG/FAM-2025', '680 KB', 'PDF', 'Dissemination detailing programmes attended, aggregate hours spent during the financial year and cumulatively by Independent Directors pursuant to Regulation 25(7) & 46(2)(i).', 'upload', NULL, 'https://www.bseindia.com/stock-share-price/amarnath-securities-ltd/amarnath/538465/', 0, 'Reg 46(2)(i) & Reg 25(7) SEBI (LODR)', '30 Aug 2025', 'FY 2024-25', 1, 'published', '698c972c-475b-4210-97c3-0eb047dbbbf9', NULL, '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('doc-pol-id-terms', 'Terms and Conditions of Appointment of Independent Directors', 'Company Policies', 'FY 2025-26', 'Annual', '10 Aug 2025', 'BSE/CORP/POL/ID-TERMS', '920 KB', 'PDF', 'Standard terms of appointment governing the role, responsibilities, tenure, code of conduct, and evaluation of Independent Directors pursuant to Schedule IV of the Companies Act, 2013 and Regulation 46(2)(b).', 'upload', NULL, 'https://www.bseindia.com/stock-share-price/amarnath-securities-ltd/amarnath/538465/', 0, 'Reg 46(2)(b) SEBI (LODR) & Schedule IV', '10 Aug 2025', 'Version 2.0', 1, 'published', '698c972c-475b-4210-97c3-0eb047dbbbf9', NULL, '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('doc-pol-mat-subsidiary', 'Policy for Determining ‘Material’ Subsidiaries', 'Company Policies', 'FY 2025-26', 'Annual', '15 Apr 2025', 'BSE/CORP/POL/MS-05', '720 KB', 'PDF', 'Criteria for identifying material subsidiaries based on income or net worth thresholds in compliance with Regulation 16(1)(c) and Regulation 46(2)(h).', 'upload', NULL, 'https://www.bseindia.com/stock-share-price/amarnath-securities-ltd/amarnath/538465/', 0, 'Reg 46(2)(h) & Reg 16(1)(c) SEBI (LODR)', '15 Apr 2025', 'Version 1.1', 1, 'published', '698c972c-475b-4210-97c3-0eb047dbbbf9', NULL, '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('doc-pol-materiality', 'Policy on Determination of Materiality for Disclosures (Regulation 30)', 'Company Policies', 'FY 2025-26', 'Annual', '15 Apr 2025', 'BSE/CORP/POL/MAT-06', '840 KB', 'PDF', 'Quantitative and qualitative thresholds, prompt disclosure protocols, and authorization under Regulation 30(4)(ii) & Regulation 46(2)(u).', 'upload', NULL, 'https://www.bseindia.com/stock-share-price/amarnath-securities-ltd/amarnath/538465/', 0, 'Reg 46(2)(u) & Reg 30(4) SEBI (LODR)', '15 Apr 2025', 'Version 2.0', 1, 'published', '698c972c-475b-4210-97c3-0eb047dbbbf9', NULL, '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('doc-pol-ned-remun', 'Criteria of Making Payments to Non-Executive Directors', 'Company Policies', 'FY 2025-26', 'Annual', '15 Apr 2025', 'BSE/CORP/POL/NED-03', '750 KB', 'PDF', 'Criteria governing sitting fees, reimbursement of expenses, and performance evaluation for non-executive and independent directors pursuant to Regulation 46(2)(f).', 'upload', NULL, 'https://www.bseindia.com/stock-share-price/amarnath-securities-ltd/amarnath/538465/', 0, 'Reg 46(2)(f) SEBI (LODR)', '15 Apr 2025', 'Version 1.2', 1, 'published', '698c972c-475b-4210-97c3-0eb047dbbbf9', NULL, '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('doc-pol-pit', 'Code of Practices and Procedures for Fair Disclosure of UPSI (SEBI PIT)', 'Company Policies', 'FY 2025-26', 'Annual', '15 Apr 2025', 'BSE/CORP/POL/PIT-08', '950 KB', 'PDF', 'Code formulated under Regulation 8 of SEBI (Prohibition of Insider Trading) Regulations, 2015 to regulate, monitor and report trading by designated persons.', 'upload', NULL, 'https://www.bseindia.com/stock-share-price/amarnath-securities-ltd/amarnath/538465/', 0, 'SEBI (PIT) Regulations, 2015', '15 Apr 2025', 'Version 2.0', 1, 'published', '698c972c-475b-4210-97c3-0eb047dbbbf9', NULL, '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('doc-pol-rpt', 'Policy on Materiality and Dealing with Related Party Transactions', 'Company Policies', 'FY 2025-26', 'Annual', '15 Apr 2025', 'BSE/CORP/POL/RPT-04', '1.1 MB', 'PDF', 'Framework for identification, threshold evaluation, prior Audit Committee approval, and periodic reporting of transactions entered into with Related Parties pursuant to Regulation 23.', 'upload', NULL, 'https://www.bseindia.com/stock-share-price/amarnath-securities-ltd/amarnath/538465/', 0, 'Reg 46(2)(g) & Reg 23 SEBI (LODR)', '15 Apr 2025', 'Version 2.1', 1, 'published', '698c972c-475b-4210-97c3-0eb047dbbbf9', NULL, '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('doc-pol-vigil', 'Vigil Mechanism / Whistle Blower Policy', 'Company Policies', 'FY 2025-26', 'Annual', '15 Apr 2025', 'BSE/CORP/POL/VM-02', '890 KB', 'PDF', 'Framework providing adequate safeguards against victimization of employees and directors reporting genuine concerns and unethical behavior pursuant to Section 177(9) and Regulation 22.', 'upload', NULL, 'https://www.bseindia.com/stock-share-price/amarnath-securities-ltd/amarnath/538465/', 0, 'Reg 46(2)(e) & Reg 22 SEBI (LODR)', '15 Apr 2025', 'Version 2.0', 1, 'published', '698c972c-475b-4210-97c3-0eb047dbbbf9', NULL, '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('doc-sec-comp-fy24', 'Annual Secretarial Compliance Report for FY 2023-24 (Regulation 24A)', 'Secretarial Compliance Report', 'FY 2023-24', 'Annual', '29 May 2024', 'BSE/LODR/20240529/77109', '1.2 MB', 'PDF', 'Secretarial compliance verification report on SEBI LODR adherence, circulars, and notifications issued by an independent PCS.', 'upload', NULL, 'https://www.bseindia.com/stock-share-price/amarnath-securities-ltd/amarnath/538465/', 0, 'Reg 24A(2) & Reg 46(2)(t) SEBI (LODR)', '31 Mar 2024', 'Version 1.0', 1, 'published', '698c972c-475b-4210-97c3-0eb047dbbbf9', NULL, '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('doc-sec-comp-fy25', 'Annual Secretarial Compliance Report for FY 2024-25 (Regulation 24A)', 'Secretarial Compliance Report', 'FY 2024-25', 'Annual', '28 May 2025', 'BSE/LODR/20250528/89104', '1.3 MB', 'PDF', 'Annual Secretarial Compliance Report issued by Practicing Company Secretary pursuant to Regulation 24A(2) of SEBI LODR Regulations.', 'upload', NULL, 'https://www.bseindia.com/stock-share-price/amarnath-securities-ltd/amarnath/538465/', 0, 'Reg 24A(2) & Reg 46(2)(t) SEBI (LODR)', '31 Mar 2025', 'Version 1.0', 1, 'published', '698c972c-475b-4210-97c3-0eb047dbbbf9', NULL, '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('doc-shp-dec-25', 'Shareholding Pattern for the Quarter ended December 31, 2025', 'Shareholding Pattern', 'FY 2025-26', 'Q3', '15 Jan 2026', 'BSE/LODR/20260115/104928', '820 KB', 'PDF', 'Statement showing shareholding pattern under Regulation 31 of SEBI (Listing Obligations and Disclosure Requirements) Regulations, 2015.', 'upload', NULL, 'https://www.bseindia.com/stock-share-price/amarnath-securities-ltd/amarnath/538465/', 0, 'Reg 31 & Reg 46(2)(m) SEBI (LODR)', NULL, 'Version 1.0', 1, 'published', '698c972c-475b-4210-97c3-0eb047dbbbf9', NULL, '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('doc-shp-sep-25', 'Shareholding Pattern for the Quarter ended September 30, 2025', 'Shareholding Pattern', 'FY 2025-26', 'Q2', '16 Oct 2025', 'BSE/LODR/20251016/948201', '790 KB', 'PDF', 'Quarterly breakdown of promoter and non-promoter public shareholding.', 'upload', NULL, 'https://www.bseindia.com/stock-share-price/amarnath-securities-ltd/amarnath/538465/', 0, 'Reg 31 & Reg 46(2)(m) SEBI (LODR)', NULL, 'Version 1.0', 1, 'published', '698c972c-475b-4210-97c3-0eb047dbbbf9', NULL, '2026-10-10 08:20:07', '2026-10-10 08:20:07');

DROP TABLE IF EXISTS `enquiries`;
CREATE TABLE `enquiries` (
  `id` varchar(50) NOT NULL,
  `reference_no` varchar(50) NOT NULL,
  `type` enum('business','investor') NOT NULL,
  `name` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `company_name` varchar(150) DEFAULT NULL,
  `service_interest` varchar(150) DEFAULT NULL,
  `estimated_capital` varchar(100) DEFAULT NULL,
  `folio_or_dp_id` varchar(100) DEFAULT NULL,
  `grievance_category` varchar(150) DEFAULT NULL,
  `details` text NOT NULL,
  `status` enum('new','in_progress','resolved','closed') NOT NULL DEFAULT 'new',
  `admin_notes` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `reference_no` (`reference_no`),
  KEY `idx_enq_type` (`type`),
  KEY `idx_enq_status` (`status`),
  KEY `idx_enq_ref` (`reference_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `enquiries` (`id`, `reference_no`, `type`, `name`, `email`, `phone`, `company_name`, `service_interest`, `estimated_capital`, `folio_or_dp_id`, `grievance_category`, `details`, `status`, `admin_notes`, `ip_address`, `created_at`, `updated_at`) VALUES
('enq-1791620744535-2c205bc1', 'ASL-CORP-428046', 'business', 'Automated Audit Client', 'audit-client@institution.com', '9820011223', 'Audit Capital Advisory LLP', 'Corporate Finance & Advisory', '₹25 Cr - ₹100 Cr', NULL, NULL, 'Audit test mandate submission verifying server-side reference generation.', 'in_progress', NULL, '127.0.0.1', '2026-10-10 08:25:44', '2026-10-10 08:25:44'),
('enq-1791620942730-3abd6c29', 'ASL-CORP-836534', 'business', 'Automated Audit Client', 'audit-client@institution.com', '9820011223', 'Audit Capital Advisory LLP', 'Corporate Finance & Advisory', '₹25 Cr - ₹100 Cr', NULL, NULL, 'Audit test mandate submission verifying server-side reference generation.', 'in_progress', NULL, '127.0.0.1', '2026-10-10 08:29:02', '2026-10-10 08:29:02'),
('enq-1791621305940-6d3b2640', 'ASL-INV-565577', 'investor', 'Kavita Sharma', 'kavita@investor.com', '9819922334', NULL, NULL, NULL, 'IN30012399887766', 'Dematerialization / Remat of Shares Query', 'Requesting confirmation of updated dematerialization status under ISIN INE745P01010.', 'new', NULL, '127.0.0.1', '2026-10-10 08:35:06', '2026-10-10 08:35:06'),
('enq-1791622206939-7911170d', 'ASL-CORP-613986', 'business', 'Automated Audit Client', 'audit-client@institution.com', '9820011223', 'Audit Capital Advisory LLP', 'Corporate Finance & Advisory', '₹25 Cr - ₹100 Cr', NULL, NULL, 'Audit test mandate submission verifying server-side reference generation.', 'in_progress', NULL, '127.0.0.1', '2026-10-10 08:50:06', '2026-10-10 08:50:06'),
('enq-1791628164511-d17607b8', 'ASL-CORP-339574', 'business', 'Automated Audit Client', 'audit-client@institution.com', '9820011223', 'Audit Capital Advisory LLP', 'Corporate Finance & Advisory', '₹25 Cr - ₹100 Cr', NULL, NULL, 'Audit test mandate submission verifying server-side reference generation.', 'in_progress', NULL, '127.0.0.1', '2026-10-10 10:29:24', '2026-10-10 10:29:24'),
('enq-1791629413179-5ba976b6', 'ASL-CORP-465975', 'business', 'Automated Audit Client', 'audit-client@institution.com', '9820011223', 'Audit Capital Advisory LLP', 'Corporate Finance & Advisory', '₹25 Cr - ₹100 Cr', NULL, NULL, 'Audit test mandate submission verifying server-side reference generation.', 'in_progress', NULL, '127.0.0.1', '2026-10-10 10:50:13', '2026-10-10 10:50:13'),
('enq-1791629450568-4ebd2241', 'ASL-CORP-650958', 'business', 'Automated Audit Client', 'audit-client@institution.com', '9820011223', 'Audit Capital Advisory LLP', 'Corporate Finance & Advisory', '₹25 Cr - ₹100 Cr', NULL, NULL, 'Audit test mandate submission verifying server-side reference generation.', 'in_progress', NULL, '127.0.0.1', '2026-10-10 10:50:50', '2026-10-10 10:50:50'),
('enq-1791629563270-29ac5b4f', 'ASL-CORP-833744', 'business', 'Automated Audit Client', 'audit-client@institution.com', '9820011223', 'Audit Capital Advisory LLP', 'Corporate Finance & Advisory', '₹25 Cr - ₹100 Cr', NULL, NULL, 'Audit test mandate submission verifying server-side reference generation.', 'in_progress', NULL, '127.0.0.1', '2026-10-10 10:52:43', '2026-10-10 10:52:43'),
('enq-1791629595617-15f66446', 'ASL-CORP-419715', 'business', 'Automated Audit Client', 'audit-client@institution.com', '9820011223', 'Audit Capital Advisory LLP', 'Corporate Finance & Advisory', '₹25 Cr - ₹100 Cr', NULL, NULL, 'Audit test mandate submission verifying server-side reference generation.', 'in_progress', NULL, '127.0.0.1', '2026-10-10 10:53:15', '2026-10-10 10:53:15'),
('enq-1791629648511-43cc4644', 'ASL-CORP-266678', 'business', 'Automated Audit Client', 'audit-client@institution.com', '9820011223', 'Audit Capital Advisory LLP', 'Corporate Finance & Advisory', '₹25 Cr - ₹100 Cr', NULL, NULL, 'Audit test mandate submission verifying server-side reference generation.', 'in_progress', NULL, '127.0.0.1', '2026-10-10 10:54:08', '2026-10-10 10:54:08'),
('enq-1791629707703-cd20a52f', 'ASL-CORP-771345', 'business', 'Automated Audit Client', 'audit-client@institution.com', '9820011223', 'Audit Capital Advisory LLP', 'Corporate Finance & Advisory', '₹25 Cr - ₹100 Cr', NULL, NULL, 'Audit test mandate submission verifying server-side reference generation.', 'in_progress', NULL, '127.0.0.1', '2026-10-10 10:55:07', '2026-10-10 10:55:07');

DROP TABLE IF EXISTS `kmp_contacts`;
CREATE TABLE `kmp_contacts` (
  `id` varchar(50) NOT NULL,
  `role_title` varchar(150) NOT NULL,
  `name` varchar(150) NOT NULL,
  `designation` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `authority_scope` text NOT NULL,
  `statutory_reference` varchar(255) NOT NULL,
  `is_verified` tinyint(1) NOT NULL DEFAULT 0,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `status` enum('draft','review','published','archived') NOT NULL DEFAULT 'published',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_kmp_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `kmp_contacts` (`id`, `role_title`, `name`, `designation`, `email`, `phone`, `address`, `authority_scope`, `statutory_reference`, `is_verified`, `sort_order`, `status`, `created_at`, `updated_at`) VALUES
('kmp-cs', 'Company Secretary & Compliance Officer', 'Mr. Atul Kumar', 'Company Secretary & Compliance Officer', 'contact.amarnathsecurities@gmail.com', '+91 99309 82815', 'Office A9, Ground Floor, Ellora Park, Near Damani Zapa, Killa Pardi, Valsad, Gujarat - 396125', 'Appointed w.e.f. August 1, 2026 pursuant to Section 203 of Companies Act, 2013 and Regulation 6(1) of SEBI (LODR) Regulations, 2015 to oversee statutory stock exchange compliance and investor grievance redressal.', 'Section 203 Companies Act & Regulation 6(1) SEBI LODR', 1, 0, 'published', '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('kmp-grievance', 'Investor Grievance Redressal Nodal Official', 'Secretarial & Investor Relations Desk', 'Designated Official for Handling Investor Inquiries', 'contact.amarnathsecurities@gmail.com', '+91 99309 82815', 'Office A9, Ground Floor, Ellora Park, Near Damani Zapa, Killa Pardi, Valsad, Gujarat - 396125', 'Dedicated corporate desk responsible for receiving, tracking and resolving shareholder grievances, physical certificate inquiries, transfer requests, and SCORES/ODR matters.', 'Regulation 13 & Regulation 46(2)(j),(k) SEBI LODR', 0, 2, 'published', '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('kmp-materiality-auth', 'Regulation 30(5) Authorized KMP for Materiality', 'Subject to Company / CS Board Resolution Confirmation', 'Authorized Key Managerial Personnel Panel (Pending Resolution Details)', 'contact.amarnathsecurities@gmail.com', '+91 99309 82815', '1/104, Sarthik Complex, Nr. Fun Republic, Satellite Road, Ahmedabad, Gujarat - 380015', 'Key Managerial Personnel specific individual names and direct contact details authorized under Regulation 30(5) of SEBI (LODR) Regulations, 2015 for determining materiality and making BSE disclosures are subject to formal confirmation by Company Secretary from Board meeting records.', 'Regulation 30(5) of SEBI (LODR) Regulations, 2015', 0, 1, 'published', '2026-10-10 08:20:07', '2026-10-10 08:20:07'),
('kmp-rta', 'Registrar & Share Transfer Agent (RTA)', 'Bigshare Services Pvt. Ltd. (Subject to Tri-Partite Agreement Confirmation)', 'SEBI Registered Category-I Registrar & Transfer Agent', 'info@bigshareonline.com', '022-62638200', 'S6-2, 6th Floor, Pinnacle Business Park, Next to Ahura Centre, Mahakali Caves Road, Andheri (East), Mumbai - 400093, Maharashtra', 'Handling dematerialization (ISIN INE745P01010), share transfers, transmissions, duplicate certificate requests, and dividend ledger maintenance. Note: Purva Sharegistry (India) Pvt. Ltd. handled historical registry liaison; confirmation of latest tripartite agreement / demat master is subject to CS verification.', 'SEBI (Registrars to an Issue and Share Transfer Agents) Regulations, 1993', 0, 3, 'published', '2026-10-10 08:20:07', '2026-10-10 08:20:07');

DROP TABLE IF EXISTS `regulation_46_clauses`;
CREATE TABLE `regulation_46_clauses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clause` varchar(30) NOT NULL,
  `sub_regulation` varchar(100) NOT NULL,
  `title` varchar(255) NOT NULL,
  `requirement` text NOT NULL,
  `category` varchar(100) NOT NULL,
  `website_location` varchar(200) NOT NULL,
  `target_route` varchar(150) NOT NULL,
  `target_category` varchar(100) DEFAULT NULL,
  `status` varchar(150) NOT NULL DEFAULT 'Company/CS Confirmation Required',
  `action_text` varchar(100) NOT NULL,
  `legal_citation` varchar(200) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `responsible_reviewer` varchar(150) DEFAULT 'Company Secretary & Compliance Officer',
  `internal_review_date` varchar(50) DEFAULT '2026-10-15',
  `evidence_link` varchar(500) DEFAULT NULL,
  `last_verified_date` varchar(50) DEFAULT NULL,
  `compliance_notes` text DEFAULT NULL,
  `review_status` enum('Not Reviewed','Pending Evidence','Under Review','Verified','Not Applicable') NOT NULL DEFAULT 'Pending Evidence',
  PRIMARY KEY (`id`),
  UNIQUE KEY `clause` (`clause`),
  KEY `idx_reg46_clause` (`clause`),
  KEY `idx_reg46_category` (`category`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `regulation_46_clauses` (`id`, `clause`, `sub_regulation`, `title`, `requirement`, `category`, `website_location`, `target_route`, `target_category`, `status`, `action_text`, `legal_citation`, `sort_order`, `created_at`, `updated_at`, `responsible_reviewer`, `internal_review_date`, `evidence_link`, `last_verified_date`, `compliance_notes`, `review_status`) VALUES
(1, '46(1)', 'Basic Website', 'Functional Website Maintenance', 'The listed entity shall maintain a functional website containing the basic information about the listed entity.', 'Website Governance', 'Homepage & Corporate Overview', 'home', NULL, 'Complied & Published', 'View Homepage', 'SEBI (LODR) Reg 46(1)', 0, '2026-10-10 08:20:07', '2026-10-10 10:55:08', 'Company Secretary & Compliance Officer', '2026-10-10', NULL, '2026-10-09', 'Automated test suite verification of website maintenance', 'Verified'),
(2, '46(2)(a)', 'Business Details', 'Details of its Business', 'Dissemination of comprehensive operational details of the business and corporate activities of the listed entity.', 'General Business', 'Business & Activities', 'capabilities', NULL, 'Complied & Published', 'View Business & Activities', 'SEBI (LODR) Reg 46(2)(a)', 1, '2026-10-10 08:20:07', '2026-10-10 10:33:04', 'Company Secretary & Compliance Officer', '2026-10-15', NULL, '2026-10-09', NULL, 'Verified'),
(3, '46(2)(aa)', 'Constitutional Charter', 'Memorandum of Association & Articles of Association (MOA & AOA)', 'Dissemination of the complete Memorandum of Association and Articles of Association as amended from time to time.', 'Charter & Incorporation', 'Disclosures & Policies / Charter Documents', 'investor-relations/policies', 'MOA & AOA', 'Company/CS Confirmation Required', 'View MOA & AOA', 'SEBI (LODR) Reg 46(2)(aa)', 2, '2026-10-10 08:20:07', '2026-10-10 08:20:07', 'Company Secretary & Compliance Officer', '2026-10-15', NULL, NULL, NULL, 'Pending Evidence'),
(4, '46(2)(ab)', 'Board Profiles', 'Brief Profile of Board of Directors', 'Brief profile of board of directors including directorship and full-time positions in body corporates.', 'Board & Governance', 'Board of Directors', 'investor-relations/board-of-directors', NULL, 'Company/CS Confirmation Required', 'View Board of Directors', 'SEBI (LODR) Reg 46(2)(ab)', 3, '2026-10-10 08:20:07', '2026-10-10 08:20:07', 'Company Secretary & Compliance Officer', '2026-10-15', NULL, NULL, NULL, 'Pending Evidence'),
(5, '46(2)(b)', 'Independent Directors', 'Terms and Conditions of Appointment of Independent Directors', 'Formal terms and conditions governing the appointment, tenure, role, and functions of independent directors.', 'Statutory Policies', 'Disclosures & Policies / Governance', 'investor-relations/policies', 'Company Policies', 'Company/CS Confirmation Required', 'View Appointment Terms', 'SEBI (LODR) Reg 46(2)(b) & Schedule IV Companies Act', 4, '2026-10-10 08:20:07', '2026-10-10 08:20:07', 'Company Secretary & Compliance Officer', '2026-10-15', NULL, NULL, NULL, 'Pending Evidence'),
(6, '46(2)(c)', 'Committees', 'Composition of Various Committees of Board of Directors', 'Composition of Audit Committee, Nomination & Remuneration Committee, Stakeholders Relationship Committee and other committees.', 'Board & Governance', 'Board Committees', 'investor-relations/committees', NULL, 'Company/CS Confirmation Required', 'View Board Committees', 'SEBI (LODR) Reg 46(2)(c) & Reg 18, 19, 20', 5, '2026-10-10 08:20:07', '2026-10-10 08:20:07', 'Company Secretary & Compliance Officer', '2026-10-15', NULL, NULL, NULL, 'Pending Evidence'),
(7, '46(2)(d)', 'Code of Conduct', 'Code of Conduct of Board and Senior Management Personnel', 'Code of conduct affirmed annually by board members and senior management pursuant to Regulation 17(5).', 'Statutory Policies', 'Disclosures & Policies', 'investor-relations/policies', 'Company Policies', 'Company/CS Confirmation Required', 'View Code of Conduct', 'SEBI (LODR) Reg 46(2)(d) & Reg 17(5)', 6, '2026-10-10 08:20:07', '2026-10-10 08:20:07', 'Company Secretary & Compliance Officer', '2026-10-15', NULL, NULL, NULL, 'Pending Evidence'),
(8, '46(2)(e)', 'Vigil Mechanism', 'Details of Establishment of Vigil Mechanism / Whistle Blower Policy', 'Details of vigil mechanism providing adequate safeguards against victimization of directors and employees who report genuine concerns.', 'Statutory Policies', 'Disclosures & Policies', 'investor-relations/policies', 'Company Policies', 'Company/CS Confirmation Required', 'View Vigil Mechanism Policy', 'SEBI (LODR) Reg 46(2)(e) & Reg 22', 7, '2026-10-10 08:20:07', '2026-10-10 08:20:07', 'Company Secretary & Compliance Officer', '2026-10-15', NULL, NULL, NULL, 'Pending Evidence'),
(9, '46(2)(f)', 'Remuneration Criteria', 'Criteria of Making Payments to Non-Executive Directors', 'Criteria of making payments to non-executive directors, if the same has not been disclosed in the annual report.', 'Board & Governance', 'Disclosures & Policies / Governance', 'investor-relations/policies', 'Company Policies', 'Company/CS Confirmation Required', 'View Remuneration Criteria', 'SEBI (LODR) Reg 46(2)(f) & Reg 19', 8, '2026-10-10 08:20:07', '2026-10-10 08:20:07', 'Company Secretary & Compliance Officer', '2026-10-15', NULL, NULL, NULL, 'Pending Evidence'),
(10, '46(2)(g)', 'RPT Policy', 'Policy on Dealing with Related Party Transactions', 'Policy on materiality of related party transactions and on dealing with related party transactions.', 'Statutory Policies', 'Disclosures & Policies', 'investor-relations/policies', 'Company Policies', 'Company/CS Confirmation Required', 'View RPT Policy', 'SEBI (LODR) Reg 46(2)(g) & Reg 23', 9, '2026-10-10 08:20:07', '2026-10-10 08:20:07', 'Company Secretary & Compliance Officer', '2026-10-15', NULL, NULL, NULL, 'Pending Evidence'),
(11, '46(2)(h)', 'Material Subsidiaries', 'Policy for Determining ‘Material’ Subsidiaries', 'Policy for determining material subsidiaries formulated pursuant to Regulation 16(1)(c).', 'Statutory Policies', 'Disclosures & Policies', 'investor-relations/policies', 'Company Policies', 'Company/CS Confirmation Required', 'View Material Subsidiary Policy', 'SEBI (LODR) Reg 46(2)(h) & Reg 16(1)(c)', 10, '2026-10-10 08:20:07', '2026-10-10 08:20:07', 'Company Secretary & Compliance Officer', '2026-10-15', NULL, NULL, NULL, 'Pending Evidence'),
(12, '46(2)(i)', 'Familiarisation Programme', 'Details of Familiarization Programmes Imparted to Independent Directors', 'Number of programmes attended, hours spent during the year and on cumulative basis, and other relevant details.', 'Board & Governance', 'Disclosures & Policies / Governance', 'investor-relations/policies', 'Corporate Governance', 'Company/CS Confirmation Required', 'View Familiarization Details', 'SEBI (LODR) Reg 46(2)(i) & Reg 25(7)', 11, '2026-10-10 08:20:07', '2026-10-10 08:20:07', 'Company Secretary & Compliance Officer', '2026-10-15', NULL, NULL, NULL, 'Pending Evidence'),
(13, '46(2)(j)', 'Grievance Redressal', 'Email Address for Grievance Redressal and Other Details', 'The designated email address and mechanism for investor grievance redressal.', 'Investor Redressal & Contacts', 'Investor Grievance & Helpdesk', 'investor-relations/grievance', NULL, 'Complied & Published', 'View Grievance Redressal', 'SEBI (LODR) Reg 46(2)(j) & Reg 13', 12, '2026-10-10 08:20:07', '2026-10-10 10:33:04', 'Company Secretary & Compliance Officer', '2026-10-15', NULL, '2026-10-09', NULL, 'Verified'),
(14, '46(2)(k)', 'Designated Officials', 'Contact Information of Designated Officials for Handling Grievances', 'Contact details of officials responsible for assisting and handling investor grievances.', 'Investor Redressal & Contacts', 'Investor Grievance & Helpdesk', 'investor-relations/grievance', NULL, 'Complied & Published', 'View Designated Officials', 'SEBI (LODR) Reg 46(2)(k) & Reg 6', 13, '2026-10-10 08:20:07', '2026-10-10 10:33:04', 'Company Secretary & Compliance Officer', '2026-10-15', NULL, '2026-10-09', NULL, 'Verified'),
(15, '46(2)(l)(i)', 'Board Meeting Notice', 'Notice of Meeting of the Board of Directors for Financial Results', 'Advance notice of board meeting where financial results shall be discussed pursuant to Regulation 29.', 'Financial Disclosures', 'BSE Disclosures / Board Notices', 'investor-relations/bse-disclosures', 'BSE Disclosures', 'Company/CS Confirmation Required', 'View Board Notices', 'SEBI (LODR) Reg 46(2)(l)(i) & Reg 29', 14, '2026-10-10 08:20:07', '2026-10-10 08:20:07', 'Company Secretary & Compliance Officer', '2026-10-15', NULL, NULL, NULL, 'Pending Evidence'),
(16, '46(2)(l)(ii)', 'Financial Results', 'Financial Results Approved by Board of Directors', 'Standalone and consolidated financial results upon conclusion of board meeting approving results.', 'Financial Disclosures', 'Financial Results', 'investor-relations/financial-results', 'Financial Results', 'Company/CS Confirmation Required', 'View Financial Results', 'SEBI (LODR) Reg 46(2)(l)(ii) & Reg 33', 15, '2026-10-10 08:20:07', '2026-10-10 08:20:07', 'Company Secretary & Compliance Officer', '2026-10-15', NULL, NULL, NULL, 'Pending Evidence'),
(17, '46(2)(l)(iii)', 'Annual Reports', 'Complete Copy of the Annual Report', 'Complete copy of annual report including balance sheet, profit and loss account, directors report, corporate governance report etc.', 'Financial Disclosures', 'Annual Reports', 'investor-relations/annual-reports', 'Annual Reports', 'Company/CS Confirmation Required', 'View Annual Reports', 'SEBI (LODR) Reg 46(2)(l)(iii) & Reg 34', 16, '2026-10-10 08:20:07', '2026-10-10 08:20:07', 'Company Secretary & Compliance Officer', '2026-10-15', NULL, NULL, NULL, 'Pending Evidence'),
(18, '46(2)(m)', 'Shareholding Pattern', 'Shareholding Pattern Submitted under Regulation 31', 'Quarterly statement showing shareholding pattern of the listed entity.', 'Shareholding', 'Shareholding Pattern', 'investor-relations/shareholding-pattern', 'Shareholding Pattern', 'Company/CS Confirmation Required', 'View Shareholding Pattern', 'SEBI (LODR) Reg 46(2)(m) & Reg 31', 17, '2026-10-10 08:20:07', '2026-10-10 08:20:07', 'Company Secretary & Compliance Officer', '2026-10-15', NULL, NULL, NULL, 'Pending Evidence'),
(19, '46(2)(n)', 'Media Agreements', 'Agreements Entered into with Media Companies / Associates', 'Details of agreements entered into with media companies and/or their associates.', 'Compliance & Secretarial Filings', 'Statutory Disclosures', 'investor-relations/bse-disclosures', NULL, 'Nil / Not Applicable (Company Confirmation Required)', 'View Media Agreements Status', 'SEBI (LODR) Reg 46(2)(n)', 18, '2026-10-10 08:20:07', '2026-10-10 10:33:04', 'Company Secretary & Compliance Officer', '2026-10-15', NULL, NULL, NULL, 'Not Applicable'),
(20, '46(2)(o)(i)', 'Analyst Meets Schedule', 'Schedule of Analysts or Institutional Investors Meet & Presentations', 'Schedule of meet at least 2 working days in advance and presentations made by the listed entity.', 'Public Relations & Analyst Meets', 'Analyst & Investor Meets', 'investor-relations/analyst-meets', 'Analyst & Investor Meets', 'Company/CS Confirmation Required', 'View Meets & Presentations', 'SEBI (LODR) Reg 46(2)(o)(i)', 19, '2026-10-10 08:20:07', '2026-10-10 08:20:07', 'Company Secretary & Compliance Officer', '2026-10-15', NULL, NULL, NULL, 'Pending Evidence'),
(21, '46(2)(o)(ii)', 'Pre-Meet Presentations', 'Presentations Prepared for Analysts / Institutional Meets or Calls', 'Presentations prepared for analysts/investors meets, post earnings or quarterly calls prior to events.', 'Public Relations & Analyst Meets', 'Analyst & Investor Meets', 'investor-relations/analyst-meets', 'Analyst & Investor Meets', 'Company/CS Confirmation Required', 'View Presentations', 'SEBI (LODR) Reg 46(2)(o)(ii)', 20, '2026-10-10 08:20:07', '2026-10-10 08:20:07', 'Company Secretary & Compliance Officer', '2026-10-15', NULL, NULL, NULL, 'Pending Evidence'),
(22, '46(2)(oa)', 'Audio / Video / Transcripts', 'Audio / Video Recordings & Transcripts of Post Earnings / Quarterly Calls', 'Audio within 24 hours/next trading day, video within 48 hours, and transcripts within 5 working days (hosted for minimum 5 years).', 'Public Relations & Analyst Meets', 'Analyst & Investor Meets', 'investor-relations/analyst-meets', 'Analyst & Investor Meets', 'Company/CS Confirmation Required', 'View Audio / Transcripts', 'SEBI (LODR) Reg 46(2)(oa)', 21, '2026-10-10 08:20:07', '2026-10-10 08:20:07', 'Company Secretary & Compliance Officer', '2026-10-15', NULL, NULL, NULL, 'Pending Evidence'),
(23, '46(2)(p)', 'Name Change', 'New Name and Old Name of Listed Entity', 'Disclosure of new name and old name for a continuous period of one year from the date of last name change.', 'Charter & Incorporation', 'Corporate Information', 'about/corporate-info', NULL, 'Complied & Published', 'View Name History', 'SEBI (LODR) Reg 46(2)(p)', 22, '2026-10-10 08:20:07', '2026-10-10 10:33:04', 'Company Secretary & Compliance Officer', '2026-10-15', NULL, '2026-10-09', NULL, 'Verified'),
(24, '46(2)(q)', 'Newspaper Publications', 'Newspaper Publications under Regulation 47(1)', 'Public notice of board meetings, financial results, notice of general meetings, dividend, loss of share certificates.', 'Newspaper Publications', 'Newspaper Publications', 'investor-relations/newspaper-publications', 'Newspaper Publications', 'Company/CS Confirmation Required', 'View Newspaper Filings', 'SEBI (LODR) Reg 46(2)(q) & Reg 47(1)', 23, '2026-10-10 08:20:07', '2026-10-10 08:20:07', 'Company Secretary & Compliance Officer', '2026-10-15', NULL, NULL, NULL, 'Pending Evidence'),
(25, '46(2)(r)', 'Credit Ratings', 'Credit Ratings Obtained for Outstanding Instruments', 'All credit ratings obtained by the entity for all its outstanding instruments, updated immediately upon any revision.', 'Financial Disclosures', 'Statutory Disclosures', 'investor-relations/bse-disclosures', NULL, 'Nil / Not Applicable (Company Confirmation Required)', 'View Credit Ratings Status', 'SEBI (LODR) Reg 46(2)(r)', 24, '2026-10-10 08:20:07', '2026-10-10 10:33:04', 'Company Secretary & Compliance Officer', '2026-10-15', NULL, NULL, NULL, 'Not Applicable'),
(26, '46(2)(s)', 'Subsidiary Accounts', 'Separate Audited Financial Statements of Each Subsidiary', 'Audited accounts of each subsidiary uploaded at least 21 days prior to AGM.', 'Financial Disclosures', 'Financial Results', 'investor-relations/financial-results', NULL, 'Nil / Not Applicable (Company Confirmation Required)', 'View Subsidiary Status', 'SEBI (LODR) Reg 46(2)(s)', 25, '2026-10-10 08:20:07', '2026-10-10 10:33:04', 'Company Secretary & Compliance Officer', '2026-10-15', NULL, NULL, NULL, 'Not Applicable'),
(27, '46(2)(t)', 'Secretarial Compliance', 'Secretarial Compliance Report under Regulation 24A(2)', 'Annual secretarial compliance report issued by practicing company secretary under Regulation 24A.', 'Compliance & Secretarial Filings', 'Secretarial Compliance Report', 'investor-relations/secretarial-compliance', 'Secretarial Compliance Report', 'Company/CS Confirmation Required', 'View Secretarial Report', 'SEBI (LODR) Reg 46(2)(t) & Reg 24A', 26, '2026-10-10 08:20:07', '2026-10-10 08:20:07', 'Company Secretary & Compliance Officer', '2026-10-15', NULL, NULL, NULL, 'Pending Evidence'),
(28, '46(2)(u)', 'Materiality Policy', 'Policy for Determination of Materiality of Events / Information', 'Disclosure of policy formulated under Regulation 30(4)(ii) for determining materiality.', 'Statutory Policies', 'Disclosures & Policies', 'investor-relations/policies', 'Company Policies', 'Company/CS Confirmation Required', 'View Materiality Policy', 'SEBI (LODR) Reg 46(2)(u) & Reg 30(4)', 27, '2026-10-10 08:20:07', '2026-10-10 08:20:07', 'Company Secretary & Compliance Officer', '2026-10-15', NULL, NULL, NULL, 'Pending Evidence'),
(29, '46(2)(v)', 'KMP Authorization', 'Contact Details of KMP Authorized under Regulation 30(5)', 'Contact details of Key Managerial Personnel authorized for determining materiality and making disclosures to stock exchange.', 'Investor Redressal & Contacts', 'Key Managerial Personnel / KMP Contacts', 'investor-relations/kmp-contacts', NULL, 'Company/CS Confirmation Required', 'View Authorized KMP', 'SEBI (LODR) Reg 46(2)(v) & Reg 30(5)', 28, '2026-10-10 08:20:07', '2026-10-10 08:20:07', 'Company Secretary & Compliance Officer', '2026-10-15', NULL, NULL, NULL, 'Pending Evidence'),
(30, '46(2)(w)', 'Material Event Archive', 'Disclosures under Sub-Regulation (8) of Regulation 30', 'Material event disclosures hosted on website for a minimum period of 5 years and thereafter as per archival policy.', 'Compliance & Secretarial Filings', 'BSE Disclosures', 'investor-relations/bse-disclosures', 'BSE Disclosures', 'Company/CS Confirmation Required', 'View Material Events Archive', 'SEBI (LODR) Reg 46(2)(w) & Reg 30(8)', 29, '2026-10-10 08:20:07', '2026-10-10 08:20:07', 'Company Secretary & Compliance Officer', '2026-10-15', NULL, NULL, NULL, 'Pending Evidence'),
(31, '46(2)(x)', 'Deviation Statements', 'Statements of Deviation(s) or Variation(s) under Regulation 32', 'Quarterly statements of deviation or variation in utilization of issue proceeds pursuant to Regulation 32.', 'Compliance & Secretarial Filings', 'Statutory Disclosures', 'investor-relations/bse-disclosures', NULL, 'Nil / Not Applicable (Company Confirmation Required)', 'View Deviation Statements', 'SEBI (LODR) Reg 46(2)(x) & Reg 32', 30, '2026-10-10 08:20:07', '2026-10-10 10:33:04', 'Company Secretary & Compliance Officer', '2026-10-15', NULL, NULL, NULL, 'Not Applicable'),
(32, '46(2)(y)', 'Dividend Policy', 'Dividend Distribution Policy under Regulation 43A', 'Dividend distribution policy by top listed entities based on market capitalization as specified in Regulation 43A(1).', 'Statutory Policies', 'Disclosures & Policies', 'investor-relations/policies', 'Company Policies', 'Nil / Not Applicable (Company Confirmation Required)', 'View Dividend Policy Status', 'SEBI (LODR) Reg 46(2)(y) & Reg 43A', 31, '2026-10-10 08:20:07', '2026-10-10 10:33:04', 'Company Secretary & Compliance Officer', '2026-10-15', NULL, NULL, NULL, 'Not Applicable'),
(33, '46(2)(z)', 'Annual Return', 'Annual Return under Section 92 of the Companies Act, 2013 (MGT-7)', 'Annual return as provided under Section 92 of Companies Act, 2013 and the rules made thereunder.', 'Compliance & Secretarial Filings', 'Annual Return (MGT-7)', 'investor-relations/annual-return', 'Annual Return (MGT-7)', 'Company/CS Confirmation Required', 'View Annual Return (MGT-7)', 'SEBI (LODR) Reg 46(2)(z) & Sec 92 Companies Act', 32, '2026-10-10 08:20:07', '2026-10-10 08:20:07', 'Company Secretary & Compliance Officer', '2026-10-15', NULL, NULL, NULL, 'Pending Evidence'),
(34, '46(2)(za)', 'ESOP Schemes', 'Employee Benefit Scheme Documents (SEBI SBEB Regulations, 2021)', 'Employee benefit scheme documents framed under SEBI (Share Based Employee Benefits & Sweat Equity) Regulations, 2021.', 'Compliance & Secretarial Filings', 'Statutory Disclosures', 'investor-relations/bse-disclosures', NULL, 'Nil / Not Applicable (Company Confirmation Required)', 'View Scheme Status', 'SEBI (LODR) Reg 46(2)(za)', 33, '2026-10-10 08:20:07', '2026-10-10 10:33:04', 'Company Secretary & Compliance Officer', '2026-10-15', NULL, NULL, NULL, 'Not Applicable'),
(35, '46(3)(a)', 'Content Accuracy', 'Accuracy of Website Disclosures', 'The listed entity shall ensure that the contents of the website are correct and accurate at all times.', 'Website Governance', 'Corporate Secretarial Oversight', 'about/corporate-info', NULL, 'Continuous Statutory Compliance', 'View Governance Protocol', 'SEBI (LODR) Reg 46(3)(a)', 34, '2026-10-10 08:20:07', '2026-10-10 10:33:04', 'Company Secretary & Compliance Officer', '2026-10-15', NULL, '2026-10-09', NULL, 'Verified'),
(36, '46(3)(b)', 'Update Timeline', 'Website Update within 2 Working Days from Content Change', 'The listed entity shall update any change in the content of its website within two working days from the date of such change in content.', 'Website Governance', 'Corporate Secretarial Oversight', 'about/corporate-info', NULL, 'Continuous Statutory Compliance', 'View Update SLA Protocol', 'SEBI (LODR) Reg 46(3)(b)', 35, '2026-10-10 08:20:07', '2026-10-10 10:33:04', 'Company Secretary & Compliance Officer', '2026-10-15', NULL, '2026-10-09', NULL, 'Verified');

DROP TABLE IF EXISTS `schema_migrations`;
CREATE TABLE `schema_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  `applied_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `schema_migrations` (`id`, `name`, `batch`, `applied_at`) VALUES
(1, '001_initial_schema.sql', 1, '2026-10-10 08:25:56'),
(3, '002_compliance_and_system_settings.sql', 2, '2026-10-10 10:33:04');

DROP TABLE IF EXISTS `system_backups`;
CREATE TABLE `system_backups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `file_size_bytes` bigint(20) NOT NULL,
  `file_size_display` varchar(50) NOT NULL,
  `backup_type` varchar(50) NOT NULL DEFAULT 'manual',
  `status` varchar(50) NOT NULL DEFAULT 'completed',
  `created_by` varchar(36) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `filename` (`filename`),
  KEY `fk_backup_user` (`created_by`),
  CONSTRAINT `fk_backup_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `system_settings`;
CREATE TABLE `system_settings` (
  `setting_key` varchar(100) NOT NULL,
  `setting_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`setting_value`)),
  `category` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `updated_by` varchar(36) DEFAULT NULL,
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`setting_key`),
  KEY `idx_settings_category` (`category`),
  KEY `fk_settings_updated_by` (`updated_by`),
  CONSTRAINT `fk_settings_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `system_settings` (`setting_key`, `setting_value`, `category`, `description`, `updated_by`, `updated_at`) VALUES
('company_profile', '{\"company_name\": \"Amarnath Securities Limited\", \"cin\": \"L67120GJ1994PLC023254\", \"bse_scrip_code\": \"538465\", \"isin\": \"INE745P01010\", \"reg_office\": \"1/104, Sona Villa Co. Op. Hsg. Soc., 280, Bara Thakur Wad, N.G. Acharya Marg, Chembur, Mumbai - 400 071, Maharashtra, India\", \"corp_office\": \"1/104, Sona Villa Co. Op. Hsg. Soc., 280, Bara Thakur Wad, N.G. Acharya Marg, Chembur, Mumbai - 400 071, Maharashtra, India\", \"email\": \"amarnathsecurities@gmail.com\", \"phone\": \"+91 22 2523 0048\", \"website\": \"https://www.amarnathsecuritiesltd.com\"}', 'company', 'Verified statutory identifiers and corporate office records', NULL, '2026-10-10 10:33:04'),
('compliance_workflow', '{\"defaultReviewer\":\"Company Secretary & Compliance Officer\",\"defaultApprover\":\"Board of Directors / Audit Committee\",\"reviewCycleDays\":90,\"nextStatutoryReviewDate\":\"2026-11-15\",\"staleReviewThresholdDays\":180}', 'compliance', 'Regulation 46 review schedule and audit sign-off workflow', '698c972c-475b-4210-97c3-0eb047dbbbf9', '2026-10-10 10:55:07'),
('investor_relations', '{\"compliance_officer\": \"Company Secretary & Compliance Officer\", \"compliance_email\": \"amarnathsecurities@gmail.com\", \"compliance_phone\": \"+91 22 2523 0048\", \"grievance_email\": \"amarnathsecurities@gmail.com\", \"rta_name\": \"Bigshare Services Pvt. Ltd.\", \"rta_address\": \"Office No S6-2, 6th Floor, Pinnacle Business Park, Next to Ahura Centre, Mahakali Caves Road, Andheri (East), Mumbai - 400 093, Maharashtra\", \"rta_email\": \"investor@bigshareonline.com\", \"rta_phone\": \"+91 22 6263 8200\", \"rta_website\": \"https://www.bigshareonline.com\", \"sebi_scores_url\": \"https://scores.sebi.gov.in\", \"sebi_smart_odr_url\": \"https://smartodr.in\", \"bse_portal_url\": \"https://www.bseindia.com/stock-share-price/amarnath-securities-ltd/amarnat/538465/\"}', 'investor', 'Designated grievance redressal and Registrar details', NULL, '2026-10-10 10:33:04'),
('notifications', '{\"emailAlertsEnabled\": false, \"adminAlertEmail\": \"compliance@amarnathsecuritiesltd.com\", \"notifyOnNewGrievance\": true, \"notifyOnDocApproval\": true, \"notifyOnFailedLoginThreshold\": true}', 'notifications', 'Event-driven alerting and grievance notification dispatch', NULL, '2026-10-10 10:33:04'),
('security_policy', '{\"minPasswordLength\": 8, \"requireSpecialChar\": true, \"sessionTimeoutMinutes\": 480, \"maxFailedLoginAttempts\": 5, \"lockoutDurationMinutes\": 15, \"enforceHttpsOnly\": true}', 'security', 'Password policy, account lockout, and session timeout parameters', NULL, '2026-10-10 10:33:04'),
('storage_settings', '{\"maxUploadSizeBytes\": 26214400, \"maxUploadSizeMb\": 25, \"allowedFileTypes\": [\"PDF\", \"XBRL\"], \"retentionPeriodYears\": 8, \"magicBytesValidation\": true}', 'storage', 'File upload constraints, storage limits, and document retention rules', NULL, '2026-10-10 10:33:04'),
('website_seo', '{\"metaTitle\": \"Amarnath Securities Limited | BSE Listed (538465) | Capital & Corporate Advisory\", \"metaDescription\": \"Amarnath Securities Limited is a BSE-listed (Scrip: 538465, CIN: L67120GJ1994PLC023254) non-banking financial services and investment advisory company.\", \"canonicalUrl\": \"https://www.amarnathsecuritiesltd.com\", \"ogImage\": \"/amarnath-logo.png\", \"keywords\": \"Amarnath Securities, BSE 538465, INE745P01010, NBFC, Investor Relations, Annual Report, Financial Results\"}', 'website', 'Statutory search engine metadata and open graph tags', NULL, '2026-10-10 10:33:04');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` varchar(36) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `name` varchar(150) NOT NULL,
  `role` enum('super_admin','compliance_officer','editor','viewer') NOT NULL DEFAULT 'editor',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `last_login_at` datetime DEFAULT NULL,
  `failed_login_attempts` int(11) NOT NULL DEFAULT 0,
  `lock_until` datetime DEFAULT NULL,
  `reset_token_hash` varchar(255) DEFAULT NULL,
  `reset_token_expires_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_users_email` (`email`),
  KEY `idx_users_role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`id`, `email`, `password_hash`, `name`, `role`, `is_active`, `last_login_at`, `failed_login_attempts`, `lock_until`, `reset_token_hash`, `reset_token_expires_at`, `created_at`, `updated_at`) VALUES
('698c972c-475b-4210-97c3-0eb047dbbbf9', 'admin@amarnathsecuritiesltd.com', '$2b$12$0cke7FAqT8XwJR.FkyrAkuRvFaueyOotyOEyU0QySxGc9Ac5CyDdW', 'Amarnath Administrator', 'super_admin', 1, '2026-10-10 10:55:07', 0, NULL, NULL, NULL, '2026-10-10 08:20:07', '2026-10-10 10:55:07');

SET FOREIGN_KEY_CHECKS = 1;
